#' NS.CA.statUtils
#'
#' Statistical utilities for overriding similarly named functions from other
#' packages (e.g., NS.CA.mode) and functions for describing (predictive) model
#' performance metrics and statistics
#'
#' @name NS.CA.statUtils
#' @docType package
NULL
