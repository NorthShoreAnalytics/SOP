require(vcd)
require(plyr)
require(lattice)
require(reshape2)

## ---- NS.CA.mode ----
#' Mode(s) of the distribution
## Arguments
#' @param  x   matrix or data frame containing the distribution(s)
#'   (convert to matrix if list)
#' @param fun   function determining which mode to select in the multimodal case
#' @return Returns the mode of the distribution

NS.CA.mode <- function(x, fun=function(y) {y}) {
  ux <- unique( x )
  t<-tabulate( match( x, ux ) )
  fun( ux[which( t == max( t ) )] )
}

## ---- matt.corr ----
#' Matthews correlation coefficient for large numbers
## Arguments
#' @param  pred   ROCR::prediction object
#' @return   Mathews correlation coefficient

matt.corr <- function( pred ) {
  mcNum <- pred@tn[[1]] * pred@tp[[1]] - pred@fn[[1]] * pred@fp[[1]]
  mcDenom <- sqrt( exp( log( pred@n.pos[[1]] ) + log( pred@n.neg[[1]] ) ) *
                     pred@n.pos.pred[[1]] * pred@n.neg.pred[[1]] )
  mc <- new( "performance")
  mc@x.name <- "Cutoff"
  mc@y.name <- "Matthews correlation coefficient"
  mc@alpha.name <- "Cutoff"
  mc@x.values <- pred@cutoffs
  mc@y.values <- list( mcNum / ( mcDenom + .Machine$double.eps ) )
  mc@alpha.values <- list()

  return( mc )
}

## ---- percent.NA.col ----
#' percentage of NAs in each column
## Arguments
#' @param x   matrix or data frame
#' @return  Returns a 1 x ncol(x) matrix or data frame with percentages of NAs
#' in x by column

percent.NA.col <- function(x) {
  cn <- colnames( x )
  lna <- lapply( cn, function( i ) nrow( x[is.na( x[, i] ),] ) / nrow( x ) )
  names( lna ) <- cn
  return( lna )

}

## ---- high.corr  ----
#' High correlation elements
#' @description Plots the correlation matrix of a dataset, returns high
#'   correlation elements
## Arguments
#' @param dataSet   orginal data set for testing the fit
#' @param minCor   lower threshold for high correlation elements
#'   (defaults to 0.6)
#' @param text   plot caption
#' @param xArg   x label arguments (defaults to \code{list( x=list( rot=90 ) )},
#'   i.e., x labels are rotated 90 degrees counterclockwise)
#' @param scaleArg   label scaling (defaults to c( cex=1 ), i.e., full size)
#' @param plotFile   file name prefix saving PDF of the plot
#'   (defaults to NA, in which case nothing is saved)
#' @param width   width of the plot in inches
#'   (defaults to 11, ignored if \code{plotFile} is missing)
#' @param height   height of the plot in inches
#'   (defaults to 8.5, ignored if \code{plotFile} is missing)
#' @param fnCor   function that defines low correlation threshold
#'   (defaults to \code{abs})
#' @param ...   additional parameters to pass to levelplot (correlation matrix
#'   plotting function)
#' @return Returns a matrix with off-diagonal high correlation elements
#'   (other entries included)

high.corr <- function(dataSet, minCor, text="Correlation matrix",
                      xArg=list( x=list( rot=90 ) ), scaleArg=c( cex=1 ),
                      plotFile=NA, width=11, height=8.5, fnCor=abs, ...) {
  nmrcCol <- which( sapply( dataSet, is.numeric ) )
  corMat <- cor( dataSet[, nmrcCol] )
  print( levelplot( corMat, scales=c( xArg, scaleArg ), main=text, ... ) )
  if ( ! is.na( plotFile ) ) {
    dev.print( device=pdf, file=plotFile, width=width, height=height )
  }
  absCor <- fnCor( corMat )
  hiCorRaw <- which( minCor <= absCor & absCor <= 1, arr.ind=T )
  hiCorRawPre <- apply( hiCorRaw, 1, function( x )
    if ( x["row"] != x["col"] ) x )
  hiCor <- hiCorRawPre[sapply( hiCorRawPre, function( y ) ! is.null( y ) )]
  hcn <- names( hiCor )
  hiCorOffDiag <- corMat[rownames( corMat ) %in% hcn,
                         colnames( corMat ) %in% hcn]
  return( hiCorOffDiag )
}

## ---- high.corr.df  ----
#' High correlation data frame
#' @description Package the elements of a (high) correlation matrix into a data
#'   frame
## Arguments
#' @param hiCor   (high) correlation matrix
#' @param minCor   lower threshold for high correlation elements
#'   (defaults to 0.6)
#' @param fnCor   function that defines low correlation threshold
#'   (defaults to \code{abs})
#' @return Returns a data frame containing:
#'   \item{var1}{first variable in a high correlation pair}
#'   \item{var2}{second variable in a high correlation pair}
#'   \item{cor}{(high) correlation value}

high.corr.df <- function( hiCor, minCor, fnCor=abs ) {
  if ( nrow( hiCor ) * ncol( hiCor ) > 0 ) {
    hiCorDf <-
      Reduce( rbind, apply( which( fnCor( hiCor ) > minCor, arr.ind=T ), 1,
                            function(c) if( c["row"] < c["col"] ) {
                              rn <- rownames( hiCor )
                              hc <- hiCor[c["row"], c["col"]]
                              data.frame( var1=rn[c["row"]], var2=rn[c["col"]],
                                          cor=hc )
                            } ) )
  } else {
    hiCorDf <- NA
  }
  return( hiCorDf )
}

## ---- odds.ratio.table  ----
#' Odds ratio statistics
#' @description Generates from a contingency table a comprehensive odds ratio
#' data frame that includes ln(odds ratio), confidence interval (CI) and p-value
#' for ln(OR), OR proper, CI(OR) and the validity indicator (valid if 1 is not
#' inside the CI).
## Arguments
#' @param m   orginal data set (matrix or data frame)
#' @param level   rejection level for the CI (defaults to 0.95 or 5\%)
#' @param lwr    column name of the lower boundary of the confidence interval
#'   (defaults to "lwr")
#' @param upr    column name of the upper boundary of the confidence interval
#'   (defaults to "upr")
#' @param oRat    column name of the log odds ratio
#'   (defaults to "Log.Odds.Ratio")
#' @return Returns a data frame with variable names as row names and odds ratio
#'   (OR) statistics as columns:
#'   \item{Log.Odds.Ratio}{ln(odds ratio)}
#'   \item{Std..Error}{standard error[ ln(odds ratio) ]}
#'   \item{z.value}{z-score of {ln(odds ratio)}}
#'   \item{Pr...z..}{probability of z.value exceeeding the significance level}
#'   \item{Log.CI.Lower}{lower confidence interval boundary of ln(odds ratio)}
#'   \item{Log.CI.Upper}{upper confidence interval boundary ln(odds ratio)}
#'   \item{Odds.Ratio}{odds ratio}
#'   \item{CI.Lower}{lower confidence interval boundary of odds ratio}
#'   \item{CI.Upper}{upper confidence interval boundary of odds ratio}
#'   \item{Validity}{statistical significance marker ('*' = valid)}

odds.ratio.table <- function( m, level=0.95, lwr="lwr", upr="upr",
                              oRat="Log.Odds.Ratio" ) {
  oRm <- oddsratio( m )
  um <- data.frame( unclass( summary( oRm ) ) )
  ci <- confint( oRm, level=level )
  um <- mutate( um,
                Log.CI.Lower=ci[1, lwr],
                Log.CI.Upper=ci[1, upr],
                CI.Lower=exp( Log.CI.Lower ),
                CI.Upper=exp( Log.CI.Upper ),
                Validity=ifelse( CI.Lower <= 1 & 1 <= CI.Upper, '', '*' ) )
  um[, "Odds.Ratio"] <- exp( um[, oRat] )
  return( um )
}

## ---- odds.ratio.matrix  ----
#' Odds ratio statistics
#' @description Generates from a data frame with row-wise outcomes a
#' comprehensive odds ratio (OR) data frame that includes ln(odds ratio),
#' confidence interval (CI) and p-value for ln(OR), OR proper, CI(OR) and the
#' validity indicator (valid if 1 is not inside the CI)
## Arguments
#' @param x   orginal data set (matrix or data frame)
#' @param outcome   (vector of) outcomes
#' @param oddsRatioCol   columns to use for calculating OR (defaults to
#' colnames(X))
#' @param ...   additional parameters to pass to
#'   \code{\link[=odds.ratio.table]{odds.ratio.table}}
#' @param level   rejection level for the CI (defaults to 0.95 or 5\%)
#' @return Returns a data frame with variable names as row names and ln(OR) and
#' OR statistics as columns:
#'   \item{Log.Odds.Ratio}{ln(odds ratio)}
#'   \item{Std..Error}{standard error[ ln(odds ratio) ]}
#'   \item{z.value}{z-score of {ln(odds ratio)}}
#'   \item{Pr...z..}{probability of z.value exceeeding the significance level}
#'   \item{Log.CI.Lower}{lower confidence interval boundary of ln(odds ratio)}
#'   \item{Log.CI.Upper}{upper confidence interval boundary ln(odds ratio)}
#'   \item{Odds.Ratio}{odds ratio}
#'   \item{CI.Lower}{lower confidence interval boundary of odds ratio}
#'   \item{CI.Upper}{upper confidence interval boundary of odds ratio}
#'   \item{Validity}{statistical significance marker ('*' = valid)}


odds.ratio.matrix <- function( x, outcome, oddsRatioCol=colnames( x ),
                               level=0.95, ... ) {
  res <- Reduce( rbind, lapply( oddsRatioCol, function( c ) {
    m <- table( x[, c], outcome )
    oRm <- odds.ratio.table( m, level=level, ... )
    rownames( oRm ) <- c
    oRm } ) )
  return( res )
}

## ---- odds.ratio.logit  ----
#' Odds ratio statistics for (primarily) numerical variables given the \
#'   (prebuilt) model
#' @description Generates from a prebuilt model a single row data frame with
#' unadjusted and adjusted odds ratios (OR) and confidence intervals (CI) for
#' OR, mean (exponential) and standard (ln) logistic multivariate model errors
## Arguments
#' @param glmFit   (generalized linear) model
#' @param coefInd   index of the coefficient of the variable in glmFit
#' @param level   rejection level for the CI (defaults to 0.95 or 5\%)
#' @return Returns a (single row) data frame with OR statistics as columns:
#'   \item{Odds.Ratio}{odds ratio}
#'   \item{Std.Error}{standard error[ ln(odds ratio) ]}
#'   \item{P.Value}{P-value of [ ln(odds ratio) ]}
#'   \item{CI.Lower}{lower confidence interval boundary of odds ratio}
#'   \item{CI.Upper}{upper confidence interval boundary of odds ratio}
#'   \item{Validity}{statistical significance marker ('*' = valid)}


odds.ratio.logit <- function( glmFit, coefInd, level=0.95 ) {
  alpha <- qnorm( level )
  glmSummary <- coef( summary( glmFit ) )
  oRat <- coef( glmFit )[coefInd]
  df <- mutate( data.frame( Odds.Ratio=exp( oRat ),
                            Std.Error=glmSummary[coefInd, "Std. Error"],
                            Pr...z..=glmSummary[coefInd, "Pr(>|z|)"] ),
                CI.Lower=exp( oRat - alpha * Std.Error ),
                CI.Upper=exp( oRat + alpha * Std.Error ),
                Validity=ifelse( abs( CI.Lower ) > 1 | abs( CI.Upper ) < 1,
                                 '*', '' ) )
  return( df )
}

## ---- odds.ratio.num  ----
#' Odds ratio statistics for (primarily) numerical variables
#' @description Generates from a data frame with row-wise outcomes a
#' comprehensive odds ratio data frame that includes the unadjusted and adjusted
#' odds ratios (OR) and confidence intervals (CI) for OR, mean (exponential) and
#' standard (ln) logistic univariate model errors
## Arguments
#' @param x   orginal data set (matrix or data frame)
#' @param outcome   (vector of) outcomes
#' @param oddsRatioCol   columns to use for calculating OR (defaults to
#' colnames(X))
#' @param level   rejection level for the CI (defaults to 0.95 or 5\%)
#' @return Returns a data frame with variable names as row names and OR and
#' OR statistics as columns:
#'   \item{Odds.Ratio}{odds ratio}
#'   \item{Std.Error}{standard error[ ln(odds ratio) ]}
#'   \item{CI.Lower}{lower confidence interval boundary of odds ratio}
#'   \item{CI.Upper}{upper confidence interval boundary of odds ratio}
#'   \item{Validity}{statistical significance marker ('*' = valid)}

odds.ratio.num <- function( x, outcome, oddsRatioCol=colnames( x ),
                            level=0.95 ) {
  xy <- data.frame( x, Status=outcome )
  univarModel <- Reduce( rbind, lapply( oddsRatioCol, function( c ) {
    uniForm <- as.formula( paste( "Status ~", c ) )
    glmFit <- glm( uniForm, xy, family='binomial' )
    df <- odds.ratio.logit( glmFit, 2, level )
    } ) )
  return( univarModel )
}

## ---- odds.ratio.multi  ----
#' Odds ratio statistics for (primarily) numerical variables
#' @description Generates from a data frame with row-wise outcomes a
#' comprehensive odds ratio data frame that includes the unadjusted and adjusted
#' odds ratios (OR) and confidence intervals (CI) for OR, mean (exponential) and
#' standard (ln) logistic univariate model errors
## Arguments
#' @param glmFit   fitted (GLM) model
#' @param level   rejection level for the CI (defaults to 0.95 or 5\%)
#' @return Returns a data frame with variable names as row names and OR and
#' OR statistics as columns:
#'   \item{Odds.Ratio}{odds ratio}
#'   \item{Std.Error}{standard error[ ln(odds ratio) ]}
#'   \item{CI.Lower}{lower confidence interval boundary of odds ratio}
#'   \item{CI.Upper}{upper confidence interval boundary of odds ratio}
#'   \item{Validity}{statistical significance marker ('*' = valid)}

odds.ratio.multi <- function( glmFit, level=0.95 ) {
  nc <- names( coef( glmFit ) )
  nc <- nc[nc != "(Intercept)"]
  multivarModel <- Reduce( rbind, lapply( 1:length( nc ), function( i ) {
    df <- odds.ratio.logit( glmFit, nc[i], level )
  } ) )
  return( multivarModel )
}

## ---- odds.ratio.stat  ----
#' Combine uni- and multivariate odds ratio statistics into one data frame
#' @description Merges a univariate odds ratio statistic with the multivariate
#' one (calculated by odds.ratio.multi) and returns both as one data frame
## Arguments
#' @param glmFit   fitted (GLM) model
#' @param uniOddRatio   (a data frame of) univariate odds ratios
#' @param level   rejection level for the CI (defaults to 0.95 or 5\%)
#' @return Returns a data frame with variable names as row names and OR and
#' OR statistics as columns:
#'   \item{Variable}{Variable name}
#'   \item{Odds.Ratio.Uni}{univariate odds ratio}
#'   \item{CI.Lower.Uni}{lower confidence interval boundary of the univariate
#'     odds ratio}
#'   \item{CI.Upper.Uni}{upper confidence interval boundary of the univariate
#'     ratio}
#'   \item{Pr...z...Uni}{z score of the univariate odds ratio}
#'   \item{Validity.uni}{statistical significance marker of the univariate odds
#'     ratio ('*' = valid)}
#'   \item{Odds.Ratio.Multi}{multivariate odds ratio}
#'   \item{CI.Lower.Multi}{lower confidence interval boundary of the
#'     multivariate odds ratio}
#'   \item{CI.Upper.Multi}{upper confidence interval boundary of the
#'     multivariate odds ratio}
#'   \item{Pr...z...Multi}{z score of the multivariate odds ratio}
#'   \item{Validity.Multi}{statistical significance marker of the multivariate
#'     multivariate odds ratio ('*' = valid)}

odds.ratio.stat <- function( glmFit, uniOddRatio, level=0.95 ) {
  coefFM <- odds.ratio.multi( glmFit, level )
  coefFM <- transform( coefFM, Variable=rownames( coefFM ) )
  coefFMoR <- merge( uniOddRatio, coefFM, by="Variable", all.x=T,
                     suffixes=c( ".Uni", ".Multi" ) )
  coefFMoR[is.na( coefFMoR )] <- ""
  coefOutCol <- c( "Variable", "Odds.Ratio.Uni", "CI.Lower.Uni", "CI.Upper.Uni",
                   "Pr...z...Uni", "Validity.Uni", "Odds.Ratio.Multi",
                   "CI.Lower.Multi", "CI.Upper.Multi", "Pr...z...Multi",
                   "Validity.Multi" )
  coefOut <- coefFMoR[, coefOutCol[coefOutCol %in% colnames( coefFMoR )]]
  return( coefOut )
}

## ---- odds.ratio.summary  ----
#' Construct a standardized odds ratio table with statistics
#' @description Standardize the ratio table created by
#'   \code{\link[=odds.ratio.matrix]{odds.ratio.matrix}} to include only
#'   "IndPosCount", "IndPosPct", "IndPosOutcomePct", "Odds.Ratio",
#'   "CI.Lower", "CI.Upper", "Pr...z..", and "Validity"
## Arguments
#' @param x   event data frame
#' @param oRi   odds ratio matrix (output of
#'   \code{\link[=odds.ratio.matrix]{odds.ratio.matrix}})
#' @param statusCol   outcome column
#' @return Returns \code{x} without sparse rows

odds.ratio.summary <- function( oRi, x, statusCol ) {
  rnORbase <- rownames(oRi)
  posCountMap <- rep( 1, length(rnORbase) )
  names(posCountMap) <- rnORbase
  posStat <- pos.stat( x, names(posCountMap), statusCol, posCountMap )

  oddsRatioInd <- merge( oRi, posStat, by="row.names", all.x=T, rownames=T )
  rownames(oddsRatioInd) <- oddsRatioInd$Row.names
  outputCol <- c( "IndPosCount", "IndPosPct", "IndPosOutcomePct",
                  "Odds.Ratio", "CI.Lower", "CI.Upper", "Pr...z..", "Validity" )

  total <- data.frame( lapply( outputCol, function( c ) NA ) )
  colnames( total ) <- outputCol
  total <- mutate( total, Row.names="TOTAL",
                   IndPosCount=nrow( x ),
                   IndPosOutcomePct=nrow( x[x[, statusCol]==1,] ) / nrow( x ) )
  oRind <- rbind( oddsRatioInd[, c( "Row.names", outputCol )], total )
  colnames( oRind )[colnames( oRind ) == "Row.names"] <- "Variable"
  return( oRind )
}

## ---- pos.stat  ----
#' Positive outcome statistics
#' @description For each specified element of the input data frame, computes
#' for count and percentage of designated "positive" values, the # of positive
#'  outcomes, and the designated "positive" value of the element.
## Arguments
#' @param x   orginal data set (matrix or data frame)
#' @param xNames   columns of x used in the calculation of statistics
#' @param outcome   name of column of x contating the output
#' @param posCountMap   map of desifganted "positive" values by parameter
#' @param posOutcome   designated outcome of interest (defaults to 1)
#' @return Returns a data frame whose columns contain:
#'   \item{IndPosCount}{# of elements of x whose value is designated "positive"}
#'   \item{IndPosPct}{percentage of "positive" parameter values as a fraction of
#'     total}
#'   \item{IndPosOutcomePct}{percentage of "positive" parameter values that
#'     correspond to positive outcomes in x }
#'   \item{PosInd}{designated "positive" value for each parameter}

pos.stat <- function(x, xNames, outcome, posCountMap, posOutcome=1) {
  posCount <- data.frame( IndPosCount=NA, IndPosPct=NA, IndPosOutcomePct=NA )
  posCount <-
    Reduce( rbind, lapply( xNames,
                           function(c) {
                             xPos <- x[x[, c]==posCountMap[[c]], ]
                             nPos <- xPos[xPos[, outcome]==posOutcome, ]
                             nX <- nrow( x )
                             pc <- mutate( posCount,
                                           PosInd=posCountMap[[c]],
                                           IndPosCount=nrow( xPos ),
                                           IndPosPct=IndPosCount / nX,
                                           IndPosOutcomePct=nrow( nPos ) /
                                             IndPosCount  )
                             rownames( pc ) <- c
                             pc
                           } ) )
  return( posCount )
}


# ---- multi.category.stats  ----
#' Relative benchmark contingency table statistics for categorical
#'   variables
#' @description For a categorical variable,
#'   \itemize{
#'     \item select a benchmark level against which the rest will be measured
#'     \item create a 2 x 2 pairwise contingency table for the remaining
#'       levels against the benchmark
#'     \item calculate \eqn{\chi^2} p-values and frequencies of outcomes of
#'       interest
#'   }
## Arguments
#' @param x   orginal data set (matrix or data frame)
#' @param multiLevCol   column of x containing the categorical variable used in
#'   the calculation of the statistics
#' @param outcome   name of column of x contating the output
#' @param rareThreshold   fraction of total below which categories are rolled up
#'   to the next level
#' @param benchmark   name of the benchmark level
#' @param multiLevColOther   name of the catgch-all category into which
#'   categories below rareThreshold are rolled up ( defaults to "Other" )
#' @param outcomeCol   column names for outcome columns
#'   ( defaults to c("0", "1") )
#' @param fnSignif   function to use for significance testing
#'   ( defaults to fisher.test )
#' @param level   rejection level for the CI (defaults to 0.95 or 5\%)
#' @param ...   additional parameters to pass to
#'   \code{\link[=odds.ratio.table]{odds.ratio.table}}
#' @return Returns a data frame whose columns contain:
#'   \item{<multiLevelCol>}{levels of the original categorical variable}
#'   \item{<outcomeCol[1]>}{counts of variables at the first outcome level}
#'   \item{<outcomeCol[2]>}{counts of variables at the second outcome level}
#'   \item{Pct}{percentage of all entries in x in the given category}
#'   \item{p.value}{\eqn{\chi^2} value that corresponds to the given category}
#'   \item{PctPos}{fraction of "positive" outcomes for the given category}

multi.category.stats <- function( x, multiLevCol, outcome, rareThreshold,
                                  benchmark, multiLevColOther="Other",
                                  outcomeCol=c("1", "0"),
                                  fnSignif=fisher.test, level=0.95, ... ) {
  miStat <- ddply( x, c( multiLevCol, outcome ),
                   function( x, colname )
                     data.frame( count=length( x[, colname] ) ),
                   colname=outcome )
  castFormula <- paste( multiLevCol,  outcome, sep="~" )
  miStat <- dcast( miStat, as.formula( castFormula ), value.var="count" )
  miStat[is.na( miStat )] <- 0
  miStat$Count <- apply( miStat[, colnames( miStat ) != multiLevCol], 1, sum )
  miStat$Pct <- miStat$Count / sum( miStat$Count )
  nonOutCol <- which( ! colnames( miStat ) %in% outcomeCol )
  outCol <- sapply( outcomeCol,
                    function( c ) which( colnames( miStat ) == c ) )
  contCol <- which( ! colnames( miStat ) %in% c( multiLevCol, "Pct", "Count" ) )
  miStatRareRow <- which( miStat$Pct < rareThreshold &
                            ! miStat[, multiLevCol] == multiLevColOther )

  miStatAddCol <- which( colnames( miStat ) %in% c( outcomeCol, "Count" ) )
  if( length( miStatRareRow ) > 0 ) {
    miStatRolled <- miStat[-miStatRareRow, ]
    cs <- colSums( miStat[miStatRareRow, miStatAddCol] )
  } else {
    miStatRolled <- miStat
    cs <- rep( 0, length( miStatAddCol ) )
  }
  otherMiStatRow <- which( miStatRolled[, multiLevCol] == multiLevColOther )
  miStatRolled[otherMiStatRow, miStatAddCol] <-
    miStatRolled[otherMiStatRow, miStatAddCol] + cs
  miStatRolled[otherMiStatRow, "Pct"] <-
    miStatRolled[otherMiStatRow, "Count"] / sum( miStatRolled$Count )
  miStatBmkRow <- which( miStatRolled[, multiLevCol] == benchmark )
  miStatRolledOut <- miStatRolled[, c( nonOutCol, outCol )]
  contCol <- which( ! colnames( miStatRolledOut ) %in%
                      c( multiLevCol, "Pct", "Count" ) )
  bmkCount <- miStatRolledOut[miStatBmkRow, contCol]
  miStatAgg <- miStatRolledOut[-miStatBmkRow, ]
  miStatOR <-
      Reduce( rbind, apply( as.matrix( miStatAgg[, contCol] ), 1, function(c) {
        contMat <- as.matrix( rbind( c, bmkCount ) )
        ct <- fnSignif( contMat )
        oR <- odds.ratio.table( contMat, level, ... )
        data.frame( P.Value=ct$p.value, oR )
      } ) )
  miStatOR[, multiLevCol] <- miStatAgg[, multiLevCol]
  miStatSummary <- merge( miStatRolledOut, miStatOR, all.x=T )
  miStatSummary <- transform( miStatSummary, IndPosOutcome=`1` / Count)
  miStatSumCol <- c(contCol, which( colnames( miStatSummary )=="Count") )
  miStatTotal <- data.frame( matrix( ncol=ncol( miStatSummary ), nrow=1 ) )
  colnames(miStatTotal) <- colnames( miStatSummary )
  miStatTotal[, miStatSumCol] <- colSums( miStatSummary[, miStatSumCol] )
  miStatTotal <- mutate( miStatTotal, IndPosOutcome=sum( X1 ) / Count )
  miStatTotal[, multiLevCol] <- "TOTAL"
  miStatSummary <- rbind( miStatSummary, miStatTotal )
  miStat <- mutate( miStatSummary, IndPosCount=Count, IndPosPct=IndPosCount /
                      miStatTotal$Count )
  resCol <- c( multiLevCol, "IndPosCount", "IndPosPct", "IndPosOutcome",
               "Odds.Ratio", "CI.Lower", "CI.Upper", "Pr...z..", "Validity" )
  return( miStat[, resCol] )
}

