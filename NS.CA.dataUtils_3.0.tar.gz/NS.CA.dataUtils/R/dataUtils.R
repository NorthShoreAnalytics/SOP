## ---- na.to.most.recent.month ----
#' Replace NA's with the most recent data from prior months
## Arguments
#' @param x   matrix or data frame containing sparse data
#' @param valid   valid numerical time points in field names
#' @param timeStr   time string pattern in field names identifying time
#'   intervals (e.g., "\\.Mo$")
#' @param mrStr   appended to newly created field names to indicate most recent
#'   data
#' @param funMR   function to use for postprocessing the the data (e.g.,
#' replacing NA's; defaults to identity function)
#' @return   The original matrix or data frame with "most recent" columns added

na.to.most.recent <- function( x, valid, timeStr, mrStr="...MR", 
                               funMR=function( y ) { y } ) {
  colMR <- grep( timeStr, colnames( x ), value=T )
  timeStamped <- unique( str_extract( colMR, "^[^.]+" ) )
  mrNameList <- NULL
  for ( ts in timeStamped ) {
    tsStr <- grep( ts, colMR, value=T )
    tsVal <- sort( as.integer( str_extract( tsStr, "\\d+" ) ) )
    tsSorted <- sapply( tsVal, function( x ) 
      grep( paste( "\\D", x, "\\D", sep="" ), tsStr, value=T ) )
    tsAcceptable <- tsSorted[which( valid %in% tsVal )]
    firstGood <- apply( x[, tsAcceptable], 1, function( x ) 
      which( !is.na( x ) ) )
    firstAcceptable <- sapply( firstGood, function( x ) 
      ifelse( length( x ) < 1, 1, min( x ) ) )
    firstAcceptable[firstAcceptable==Inf] <- 1
    firstGood <- cbind( as.integer( rownames( x ) ), firstAcceptable )
    mrName <- paste( ts, mrStr, sep="" )
    mrNameList <- c( mrNameList, mrName )
    x[, mrName] <- x[, tsAcceptable][firstGood]
  }
  x[, mrNameList] <- funMR( x[, mrNameList] )
  return( x )
}


## ---- na.to.colMeans ----
#' Replace NA's with column means
## Arguments
#' @param x  matrix or data frame containing sparse data;
#'   convert x to matrix if it isn't
#' @return   The original matrix or data frame with NA's filled

na.to.colMeans <- function( x ) {
  k <- which( is.na( x ), arr.ind=TRUE )
  x[k] <- colMeans( x, na.rm=TRUE )[k[, 2]]
  return( x )
}

## ---- na.to.rowMeans ----
#' Replace NA's with row means
## Arguments
#' @param x  matrix or data frame containing sparse data;
#'   convert x to matrix if it isn't
#' @return   The original matrix or data frame with NA's filled

na.to.rowMeans <- function( x ) {
  k <- which( is.na( x ), arr.ind=TRUE )
  x[k] <- rowMeans( x, na.rm=TRUE)[k[, 1]]
  return( x )
}

## ---- na.to.col.mode ----
#' Replace NA's with column modes
#' @param x  matrix or data frame containing sparse data;
#'   convert x to matrix if it isn't
#' @return   The original matrix or data frame with NA's filled

na.to.col.mode <- function( x ) {
  k <- which( is.na( x ), arr.ind=TRUE )
  x[k] <- NS.CA.mode( x )[k[, 2]]
  return( x )
}

## ---- na.to.col.mode.2 ----
#' Replace NA's with column modes ( corrected 
#'   \code{\link[=NS.CA.dataUtils]{na.to.col.mode}} )
#' @param x  matrix or data frame containing sparse data;
#'   convert x to matrix if it isn't
#' @param fn   tiebreaker function in case of multimodality (defaults to 
#'   \code{max( c, na.rm=T )})
#' @param ...   additional parameters passed to \code{fn}
#' @return   The original matrix or data frame with NA's filled

na.to.col.mode.2 <- function( x, fn=function( c ) max( c, na.rm=T ), ... ) {
  k <- which( is.na( x ), arr.ind=TRUE )
  x[k] <- sapply( 1:ncol( x ), function( i ) NS.CA.mode( x[,i], fn, ... ) )
  return( x )
}

## ---- na.to.row.mode ----
#' Replace NA's with row modes
## Arguments
#' @param x  matrix or data frame containing sparse data;
#'   convert x to matrix if it isn't
#' @return   The original matrix or data frame with NA's filled
#'
na.to.row.mode <- function( x ) {
  k <- which( is.na( x ), arr.ind=TRUE )
  x[k] <- NS.CA.mode( x )[k[, 1]]
  return( x )
}

## ---- pattern.to.str ----
#' Replace a pattern with a string
## Arguments
#' @param x   matrix or data frame containing sparse data
#' @param pattern   what to replace
#' @param str   replacement
#' @return   The original with pattern changed to str

pattern.to.str <- function( x, pattern, str ) {
  y <- sapply( x, as.character )
  y[pattern( y )] <- str
  clX <- class( x )
  return( do.call( clX, apply( y, 2, clX ) ) )
}


## ---- apply.na.omit ----
#' Apply a function to all values that are not empty, NAs for empty values
## Arguments
#' @param x   data frame or matrix
#' @param i   dimension of application: 1 - rows, 2 columns (see "apply")
#' @param fn   function to apply
#' @param ...   parameters passed to fn
#' @return   A list of resulting function applications

apply.na.omit <- function( x, i, fn, ... ) {
  res <- NA
  if ( dim( x )[1] <= 1 ) {
    xn <- na.omit( x )
    if ( length( xn ) > 0 ) {
      res <- min( xn )
    }
  } else {
    l <- apply( x, i, na.omit )
    res <- sapply( l, function( v ) 
      ifelse( length( v ) == 0, NA, fn( v, ... ) ) )
  }
  return( res )
}


## ---- bind.with.field  ----
#' Add a field to non-null elements of a data frame
## Arguments
#' @param x   data frame of dates
#' @param field   name of the field to add
#' @param c   field value(s)
#' @return The original data frame with the field added

bind.with.field <- function( x, field, c ) {
  if ( !is.null( x ) ) {
    x[, field] <- c
  }
  return( x )
}

## ---- remove.col.by.name  ----
#' Remove column(s) by name or number
#' or matrix
## Arguments
#' @param lx   list of data frames or matrices
#' @param field - name of the field to add
#' @param isStr (logical)   is this a column name?
#' @return   original (list of) data frame(s) with the field(s) removed

remove.col.by.name <- function( lx, field, isStr ) {
  for ( y in lx ) {
    if ( isStr )
      y <- y[, ! colnames( y ) %in% field]
    else
      y <- y[, -field]
  }
  return( lx )
}

## ---- list.search  ----
#' Find entries in a list
#' @description Finds names of element(s) of a named list element by value
## Arguments
#' @param l   named list
#' @param c - value to find in \code{l}
#' @return   names of element(s) of \code{l} whose values are equal to \code{c}

list.search <- function( l, c ) {
  return( names( l[sapply( l, function( x ) c %in% x )] ) )
}

## ---- list.invert  ----
#' Swaps names and values in an isomorphic list
#' @description In an isomorphic (1:1, or bijection) list, inverts the 
#'   relationship turning names into values and values into names
## Arguments
#' @param l   named list
#' @return   original list indexed by values with values set to original names

list.invert <- function( l ) {
  lVal <- unlist( l )
  lInv <- lapply( lVal, function( c ) list.search( l, c ) )
  names( lInv ) <- as.numeric( lVal )
  return( lInv )
}

## ---- map.direct  ----
#' Hash table (map)
#' @description Finds the value in a hash table (map) given by a mapping 
#'   function corresponding to the given key
## Arguments
#' @param key   key to look for   
#' @param map   mapping function
#' @param ... additional parameters passed to \code{map}   
#' @return    value in the map corresponding to the supplied key

map.direct <- function( key, map, ... ) {
  return( map( key, ... ) )
}

## ---- map.invert  ----
#' Key(s) from a map by value
#' @description Given a mapping (hash) function, finds keys corresponding to a 
#'   given value by calling \code{\link[=NS.CA.dataUtils]{list.invert}})
## Arguments
#' @param value   value to find in the map
#' @param mapFn   mapping function
#' @param ... additional parameters passed to \code{mapFn}   
#' @return    name(s) in the map corresponding to the supplied value

map.invert <- function( value, mapFn, ... ) {
  return( list.invert( mapFn( ... ) )[[as.character( value )]] )
}

## ---- case.sentence  ----
#' String to sentence case (first capital) or from sentence case to lower case
## Arguments
#' @param x   string to convert
#' @param inverse   if TRUE, convert \code{x} to sentence case, otherwise, to
#'   lower case
#' @return    original string in sentence or lower case


case.sentence <- function( x, inverse=T ) {
  res <- NA
  if ( ! inverse ) {
    res <- sub( "(\\b[a-z])", "\\U\\1", x, perl=T )
  } else {
    res <- sub( "(\\b[A-Z])", "\\L\\1", x, perl=T )
  }
  return( res )
}

## ---- group.by.col  ----
#' Group data frame by columns using \code{\link[=dplyr]{group_by}}
## Arguments
#' @param x   data frame
#' @param groupCol   names of columns of \code{x} by which to group
#' @return    original data frame grouped by columns

group.by.col <- function( x, groupCol ) {
  return( do.call( function( ... ) group_by( x, ... ), 
                   lapply( groupCol, as.symbol ) ) )
}

## ---- factor.to.numeric  ----
#' Convert factor data to numeric
## Arguments
#' @param x   factor data
#' @return    original factor data converted to numeric

factor.to.numeric <- function( x ) {
  return( as.numeric( levels( x )[x] ) )
}

## ---- df.to.zoo  ----
#' Convert a data frame to zoo
## Arguments
#' @param x   data frame
#' @param indCol   time-generating columns of \code{x} 
#'   (defaults to \code{c( "date", "hour" )})
#' @param format   format for converting \code{indCol} to time
#'   (defaults to \code{"\%F \%H"})
#' @param tz   time zone for time (defaults to \code{"UTC"})
#' @return    \code{zoo} object generated from \code{x}

df.to.zoo <- function( x, indCol=c( "date", "hour" ), format="%F %H", 
                       tz="UTC" ) {
  return( 
    read.zoo( x, index.column=lapply( indCol,  
                                      function( c ) grep( c, colnames( x ) ) ),
              FUN=function( d, h ) strptime( paste( d, h ), format, tz=tz ) ) 
  )
}
