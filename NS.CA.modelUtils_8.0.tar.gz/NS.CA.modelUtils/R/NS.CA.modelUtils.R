#' NS.CA.modelUtils.
#'
#' Model performance statistics, test programming and graphing
#'
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @name NS.CA.modelUtils
#' @docType package
#' @param AUC.MFROW c( 2, 2 )
#' @param AUC.OMA c( 0, 0, 2, 0 )
#' @param AUC.THRESHOLD 0.05
#' @param AUC.PERIOD <- years( 1 )
#' @param SPARSE.MIN <- 0.2
#' @param CORR.MIN <- 0.6
#' @param SIG.LEV <- 0.95
#' @param ID.COL <- "PAT_MRN_ID"
#' @param PRED.COL <- "Predicted"
#' @param ACT.COL <- "Actual"
#' @param TIMESTAMP <- timestamp.from.date() 
#' @param COX.ITER.MAX <- 100
#' @param PERF.DIGITS <- 4

NULL
