#' NS.CA.modelUtils.
#'
#' Model performance statistics, test programming and graphing
#'
#' @name NS.CA.modelUtils
#' @docType package
#' @param AUC.MFROW c( 2, 2 )
#' @param AUC.OMA c( 0, 0, 2, 0 )
#' @param AUC.THRESHOLD 0.05
#' @param AUC.PERIOD <- years( 1 )
#' @param SPARSE.MIN <- 0.2
#' @param CORR.MIN <- 0.6
#' @param SIG.LEV <- 0.95
#' @param ID.COL <- "PAT_MRN_ID"
#' @param PRED.COL <- "Predicted"
#' @param ACT.COL <- "Actual"
#' @param TIMESTAMP <- timestamp.from.date() 
#' @param COX.ITER.MAX <- 100
#' @param PERF.DIGITS <- 4

NULL
