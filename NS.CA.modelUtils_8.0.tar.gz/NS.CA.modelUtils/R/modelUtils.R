# graph display constants

AUC.MFROW <- c(2, 2)
AUC.OMA <- c(0, 0, 3, 0)
AUC.THRESHOLD <- 0.05
AUC.PERIOD <- years(1)
SPARSE.MIN <- 0.2
CORR.MIN <- 0.6
SIG.LEV <- 0.95
ID.COL <- "PAT_MRN_ID"
PRED.COL <- "Predicted"
ACT.COL <- "Actual"
TIMESTAMP <- timestamp.from.date() 
COX.ITER.MAX <- 100
PERF.DIGITS <- 4

## ---- auc.perf.base ----
#' Model performance evaluation
#' @description Plots AUC, Matthews correlation coefficient and F1 score
## Arguments
#' @param prediction  predicted data
#' @param status  observed (actual) outcomes
#' @param digits   # of decimal digits to display on the AUC graph
#'   (defaults to \code{\link[=NS.CA.modelUtils]{PERF.DIGITS}}))
#' @param text   graph caption (defaults to an empty string)
#' @param mfrow   graph panel parameters (defaults to
#'   \code{\link[=NS.CA.modelUtils]{AUC.MFROW}})
#' @param oma   graph margin parameters (defaults to
#'   \code{\link[=NS.CA.modelUtils]{AUC.OMA}})
#' @param plotFile   name of the file for saving PDF of the plot 
#'   (defaults to NA, in which case nothing is saved)
#' @param width   width of the plot in inches 
#'   (defaults to 11, ignored if \code{plotFile} is missing)
#' @param height   height of the plot in inches 
#'   (defaults to 8.5, ignored if \code{plotFile} is missing)
#' @return Returns a list of model outputs:
#'   \item{pred}{prediction object from ROCR}
#'   \item{perf}{tpr/fpr performance object from ROCR}
#'   \item{auc}{full AUC object}
#'   \item{mat}{Matthews correlation coefficient}
#'   \item{f1}{f1 score}


auc.perf.base <- function( prediction, status, digits=PERF.DIGITS, text="", 
                           mfrow=AUC.MFROW, oma=AUC.OMA, plotFile=NA, width=11, 
                           height=8.5 ) {
  pred <- ROCR::prediction( prediction, status )
  perf <- performance( pred, 'tpr', 'fpr' )
  auc <- performance( pred, 'auc' )
  # mat <- performance( pred, 'mat' ) - does not work for large numbers
  mat <- matt.corr( pred )
  f1 <- performance( pred, 'f' )
  aucVal <- unlist( slot( auc, 'y.values' ) )
  oldPar <- par()[c( "mfrow", "oma" )]
  par( mfrow=mfrow, oma=oma )
  plot( perf, main=paste('AUC =', format( aucVal, digits=digits ) ) )
  plot( mat, main='Matthews correlation coefficient' )
  plot( f1, main='F1 score' )
  mtext( text, adj=0.5, side=3, outer=T, font=2 )
  if ( ! is.na( plotFile ) ) {
    dev.print( device=pdf, file=plotFile, width=width, height=height )
  }
  par( mfrow=oldPar$mfrow, oma=oldPar$oma )
  return( list( pred=pred, perf=perf, auc=auc, mat=mat, f1=f1 ) )
}

## ---- auc.perf ----
#' Model performance evaluation
#' @description Plots AUC, Matthews correlation coefficient and F1 score
## Arguments given the model (calls 
#'   \code{\link[=NS.CA.modelUtils]{auc.perf.base}})
#' @param model  evaluated model
#' @param test  testing data set
#' @param status  observed (actual) outcomes
#' @param type  type of predicted response (probability, response etc.)
#' @param ...   additional arguments passed to
#'   \code{\link[=NS.CA.modelUtils]{auc.perf.base}}
#' @return Returns a list of model outputs:
#'   \item{predicted}{predicted outcomes}
#'   \item{pred}{prediction object from ROCR}
#'   \item{perf}{tpr/fpr performance object from ROCR}
#'   \item{auc}{full AUC object}
#'   \item{mat}{Matthews correlation coefficient}
#'   \item{f1}{f1 score}


auc.perf <- function( model, test, status, type, ... ) {
  predictLm <- predict( model, newdata=test, type )
  ap <- auc.perf.base( predictLm, status, ... )
  return( c( list( predicted=predictLm ), ap ) )
}


## ---- surv.time.max  ----
#' Maximum survival time
## Arguments
#' @param dt   list or data frame of time intervals with possible NAs
#' @param startDate   list of interval starting dates
#' @param maxDate   scalar or list of cutoff dates
#' @param maxVal   maximum value for the interval (defaults to 1e10)
#' @return Returns a list or data frame of intervals where NAs are backfilled
#'   with maximum observation lengths

surv.time.max <- function( dt, startDate, maxDate, maxVal = 1e10 ) {
  p <- pattern.to.str(data.frame(dt), function(y) which(is.na(y)), maxVal)[,1]
  return( pmin( as.numeric(as.character(p)), maxDate-startDate ) )
}

## ---- forward.test.dates  ----
#' Set up forward test program
#' @description Break up dates into training and testing datasets allowing for
#'   at least one observed period after the last test date
## Arguments
#' @param dates   list of dates (for which data is available)
#' @param dateNow   today's date (defaults to system date)
#' @param period   (observation) period (defaults to
#'   \code{\link[=NS.CA.modelUtils]{AUC.PERIOD}})
#' @return Returns a list of vectors of dates:
#'   \item{Train}{for the training data set(first period)}
#'   \item{Test}{for all other periods at least one period prior to today}


forward.test.dates <- function( dates, dateNow=Sys.Date(), period=AUC.PERIOD ) {
  timeToNow <- interval(dates, dateNow) %/% period
  lastDateInd <- which.min(timeToNow[(which(timeToNow-1 >=0 ))])
  res <- NULL
  if ( length(lastDateInd) > 0 ) {
    res <- list( Train=dates[1] )
    if (lastDateInd >= 2) {
      res$Test = dates[2:lastDateInd]
    }
  }
  return( res )
}

## ---- backward.test.dates  ----
#' Set up backward test program
#' @description Break up dates into training and testing datasets allowing for
#'   at least one observed period after the training date
## Arguments
#' @param dates   list of dates (for which data is available)
#' @param dateNow   today's date (defaults to system date)
#' @param period   (observation) period (defaults to
#'   \code{\link[=NS.CA.modelUtils]{AUC.PERIOD}})
#' @return Returns a list of vectors of dates:
#'   \item{Train}{for the training data set(first period)}
#'   \item{Test}{for all other periods at least one period prior to today}


backward.test.dates <- function( dates, dateNow=Sys.Date(),
                                 period=AUC.PERIOD ) {
  timeToNow <- interval(dates, dateNow) %/% period
  lastDateInd <- which.min(timeToNow[(which(timeToNow-1 >=0 ))])
  res <- NULL
  if ( length(lastDateInd) > 0 ) {
    res <- list( Train=dates[lastDateInd] )
    if (lastDateInd >= 2) {
      res$Test = dates[1:(lastDateInd-1)]
    }
  }
  return( res )
}

## ---- mid.test.dates  ----
#' Set up backward test program
#' @description Break up dates into training and testing datasets allowing for
#'   at least one observed period after the training date
## Arguments
#' @param dates   list of dates (for which data is available)
#' @param dateNow   today's date (defaults to system date)
#' @param period   (observation) period (defaults to
#'   \code{\link[=NS.CA.modelUtils]{AUC.PERIOD}})
#' @return Returns a list of vectors of dates:
#'   \item{Train}{for the training data set(first and last period)}
#'   \item{Test}{for all other periods in between}


mid.test.dates <- function( dates, dateNow=Sys.Date(), period=AUC.PERIOD ) {
  timeToNow <- interval(dates, dateNow) %/% period
  lastDateInd <- which.min(timeToNow[(which(timeToNow-1 >=0 ))])
  res <- NULL
  if ( length(lastDateInd) > 0 ) {
    res <- list( Train=unique(dates[c(1, lastDateInd)]) )
    if (lastDateInd >= 3) {
      res$Test = dates[2:(lastDateInd-1)]
    }
  }
  return( res )
}


## ---- glm.test  ----
#' glm (classification) model fit assessment
#' @description Runs glm (classification) model fit assessments on a dataset
## Arguments
#' @param dataSet   orginal data set for testing the fit
#' @param statusCol   (observed) outcomes
#' @param testRows   rows belonging to the testing set
#' @param threshold   classification sensitivity threshold (i.e., what fraction
#'   of dataSet we are selecting as having an outome of interest; defaults to
#'   \code{\link[=NS.CA.modelUtils]{AUC.THRESHOLD}})
#' @param family   model family (defaults to 'binomial')
#' @param type   response type for prediction (defaults to 'response')
#' @param trace   (logical) trace the convergence? (defaults to FALSE)
#' @param maxit   max # of iterations (defaults to 25)
#' @param varJoiner   variable joiner parameter: '+', '*' or ':'
#'   ( defaults to '+')
#' @param corrMat   (logical) display correlation matrix plot (defaults to F)
#' @param ...   additional arguments passed to
#'   \code{\link[=NS.CA.modelUtils]{auc.perf}}
#' @return Returns a list of vectors of dates:
#'   \item{model}{glm model}
#'   \item{eff}{predicted and actual outcomes side by side}
#'   \item{mean}{PPV of up to threshold highest ranking outcomes of interest}
#'   \item{perf}{model statistics (including auc) passed up from 
#'      \code{auc.perf}}

glm.test <- function( dataSet, statusCol, testRows, threshold=AUC.THRESHOLD,
                      family='binomial', type='response', trace=F, maxit=25,
                      varJoiner='+', corrMat=F, ... ) {
  test  <- dataSet[testRows, -statusCol]
  testStatus <- dataSet[testRows, statusCol]
  train <- dataSet[-testRows, -statusCol]
  trainStatus <- dataSet[-testRows, statusCol]
  excludedColTrain <-  which(sapply(train, function(c) length(unique(c))) < 2)
  if ( length(excludedColTrain) > 0 ) {
    train <- train[, -excludedColTrain]
    test <- test[, -excludedColTrain]
  }

  ## the model

  predictors <- names(train)
  lmForm <- as.formula(paste("Status ~ ", paste(predictors, 
                                                collapse=varJoiner )))

  trainData <- cbind( train, Status=trainStatus )
  glmFit <- glm( lmForm, data=trainData, family=family, trace=trace )
  testLm <- test
  res <- auc.perf( glmFit, testLm, testStatus, type=type, ... )

  eff <- cbind(testStatus, res$predicted)
  meanMod <- mean(eff[order(-eff[, 2]),][1:(threshold*nrow(eff)), 1])
  return ( list( model=glmFit, eff=eff, mean=meanMod, perf=res) )
}

## ---- glm.validate.time  ----
#' Validate glm (classification) model
#' @description Validates glm (classification) model according to the rules
#'   provided by a parameter function
## Arguments
#' @param dataSet   orginal data set for testing the fit
#' @param statusCol   (observed) outcomes
#'
#' @param testDates   Test dates within dataSet
#' \code{\link[=NS.CA.modelUtils]{AUC.PERIOD}}), \cr
#'     where: \cr
#'       \describe{
#'         \item{dates}{list of dates}
#'         \item{dateNow}{date}
#'         \item{period}{(lubridate) Period}
#'       }
#' @param threshold   classification sensitivity threshold (i.e., what fraction
#'   of dataSet we are selecting as having an outome of interest; defaults to
#'   \code{\link[=NS.CA.modelUtils]{AUC.THRESHOLD}})
#' @param dateField   date filed in dataSet (defaults to "AS_OF_DATE")
#' @param period   (lubridate) Period between dataset dates (defaults to
#'   \code{\link[=NS.CA.modelUtils]{AUC.PERIOD}})
#' @param corrMat   (logical) display correlation matrix plot (defaults to F)
#' @param ...   additional arguments passed to
#'   \code{\link[=NS.CA.modelUtils]{auc.perf}}
#' @return Returns a list of vectors of dates:
#'   \item{model}{glm model}

glm.validate.time <- function( dataSet, statusCol, testDates,
                               threshold=AUC.THRESHOLD, dateField="AS_OF_DATE",
                               period=AUC.PERIOD, corrMat=F, ... ) {
  trainRows <- which( ! dataSet[, dateField] %in% testDates )
  trainDateStr <- Reduce( function( ... ) paste( ..., sep=", " ),
                          unique( dataSet[trainRows, dateField] ) )
  model <- lapply( testDates, function( d ) {
    testRows <- which( dataSet[, dateField] == d )
    testDateStr <- Reduce( function( ... ) paste( ..., sep=", " ),
                           unique( dataSet[testRows, dateField] ) )
    dataTrainTest <- dataSet[c( trainRows, testRows ), ]
    text <- paste( text, "\n train date(s)", trainDateStr, ", test date(s)",
                   testDateStr )
    dataTestRows <- which( dataTrainTest[, dateField] == d )
    glm.test( dataTrainTest, statusCol, dataTestRows, threshold, 
              corrMat=corrMat, ... )
  } )
  names( model ) <- testDates
  return( model )
}

## ---- perf.clsf.stat  ----
#' Performance statistics for a classification model
#' @description Provides validation statistics for a classification model
#'   based on predicted (and, if availabel, actual) outcomes
## Arguments
#' @param predicted   predicted outcomes
#' @param totalSize   size of the original (whole) data set (defaults to
#'   \code{nrow( predicted )}
#' @param actual   Observed outcomes (defaults to NULL)
#' @return Returns a data frame of model performance metrics sorted by predicted
#'   values in descending order with columns: \cr
#'     Regardless of whether outcomes in \code{actual} were supplied
#'       \item{Predicted}{predicted values}
#'       \item{Number.Flagged}{# of entries flagged in the testing data set as
#'         having positive outcomes}
#'       \item{Number.In.Whole}{# of entries flagged in the whole data set
#'         (training + testing) as having positive outcomes}
#'     \cr
#'     ONLY if outcomes in \code{actual} were supplied
#'       \item{Actual}{(if actual is supplied) observed outcomes}
#'       \item{Number.Actual}{# of observed positive outcomes}
#'       \item{PPV}{positive predictive value}
#'       \item{Sensitivity}{model sensitivity}
#'       \item{Lift}{model lift at the given point}

perf.clsf.stat <- function( predicted, totalSize=nrow( predicted ), 
                            actual=NULL ) {
  pr <- data.frame( Predicted=predicted )
  nPr <- nrow( pr )
  if ( nPr == length( actual ) ) {
    pr <- transform( pr, Actual=actual )
  }
  
  prSort <- data.frame(pr[order( pr$Predicted, decreasing=T ), ])
  prSort <- transform( prSort, Number.Flagged=as.numeric( row( prSort )[, 1] ) )
  
  # don't want to use mutate  since it drops row names
  
  prSort <- transform( prSort, 
                       Number.In.Whole=NS.CA.round( exp( log( Number.Flagged ) +
                                                           log( totalSize ) - 
                                                           log( nPr ) ) ),
                       Percent.Flagged=Number.Flagged / nrow( prSort ) )

  if ( "Actual" %in% colnames( prSort ) ) {
    prSort <- transform( prSort, Number.Actual=cumsum( Actual ) )
    prSort <- transform( prSort, PPV=Number.Actual / Number.Flagged,
                         Sensitivity=Number.Actual / max( Number.Actual ) )
    prSort <- transform( prSort, Lift=Sensitivity / Percent.Flagged )
  }

  return( prSort )
}

## ---- lift.table  ----
#' Lift table
#' @description Tabulates PPV and sensitivity at specified points by percentage
#'   using linear approximation
## Arguments
#' @param x  model performance data frame
#' @param pctList   vector of data points (percentages) for which lift
#'   statistics are sought
#' @param totalSize   total population size
#' @param actPosCol   column of \code{x} containing the # of actual positive
#'   cases in the percentage of the test population given by \code{pctList}
#'   (defaults to "Number.Actual")
#' @param actCol   column of \code{x} containing the # of actual positive cases
#'   in the test population (defaults to "Number.Actual")
#' @param pctCol   column of \code{x} containing the percentage (flagged) column
#'   in x (defaults to "Percent.Flagged")
#' @param ppvCol   column of \code{x} containing positive predictive value (PPV)
#'   (defaults to "PPV")
#' @param sensCol    column of \code{x} containing sensitivity
#'   (defaults to "Sensitivity")
#' @return Returns a data frame of lift statistics:
#'   \item{Pct.Total}{percentage of total population for which lift statistics
#'     is sought}
#'   \item{Num.Flagged.Total}{# of entries in the total population corresponding
#'     to \code{Pct.Total}}
#'   \item{Num.Flagged.Test}{# of flagged entries in the test dataset
#'     corresponding to \code{Pct.Total}}
#'   \item{Num.True.Pos.Test}{# of true positives in the test dataset
#'     corresponding to \code{Pct.Total}}
#'   \item{PPV}{positive predicted value}
#'   \item{Sensitivity}{sensitivity}
#'   \item{F1}{F1 statistic (harmonic average of \code{PPV} and
#'     \code{Sensitivity})}

lift.table <- function( x, pctList, totalSize, pctCol="Percent.Flagged",
                        actPosCol="Number.Actual", actCol="Actual",
                        ppvCol="PPV", sensCol="Sensitivity" ) {
  lt <- Reduce( rbind, lapply( pctList, function( p ) {
    
    # don't want to use mutate  since it drops row names
    
    df <- 
      transform( data.frame( Pct.Total=p,
                             Num.Flagged.Total=NS.CA.round( p * totalSize ),
                             Num.Flagged.Test=NS.CA.round( p * nrow(x) ),
                             Num.True.Pos.Test=NS.CA.round( 
                               approx( x[, pctCol], x[, actPosCol], p )$y ) ) )
    df <- transform( df, PPV=Num.True.Pos.Test / Num.Flagged.Test,
                     Sensitivity=Num.True.Pos.Test / sum( x[, actCol] ) )
    transform( df, F1= 2.0 / ( 1 / PPV + 1 / Sensitivity ) )
  } ) )
  return( lt )
}

## ---- rand.surv  ----
#' Random selection of survivor's data
#' @description Select one row of data for those patients in the mortality model
#'   who remained alive for at least two dates during the observation period. 
#'   If patient has only one row, it is returned, otherwise one is selected at 
#'   random from all patient's data.
## Arguments
#' @param x   patient data frame
#' @param field   patient identifier (defaults to 
#'   \code{\link[=NS.CA.modelUtils]{ID.COL}})
#' @param seed    random sampler seed (defaults to NULL, (quasi)random)
#' @return Returns a vector of row numbers

rand.surv <- function( x, field=ID.COL, seed=NULL ) {
  patFreq <- ddply( x, field, function( y, c ) Count=length( y[, c] ), field )
  patRows <- sapply( patFreq[, field], function( c ) {
    rl <- which( x[, field] == c )
    set.seed( seed )
    rl[sample( length ( rl ), 1 )] } )
  return( patRows )
}

## ---- rem.sparse.col  ----
#' Remove sparse columns from a data matrix
#' @description Remove from a data frame those columns where more than 
#'   \code{\link[=NS.CA.modelUtils]{SPARSE.MIN}}) of the data is absent
## Arguments
#' @param x   event data frame
#' @param trainRows   rows of \code{x} used for the training dataset
#' @param col   columns of interest
#' @param sparseMin   threshold proportion of missing values above which a 
#'   column is ignored
#' @return Returns \code{x} without sparse rows

rem.sparse.col <- function( x, trainRows, col, sparseMin = SPARSE.MIN ) {
  pctNA <- percent.NA.col( x[trainRows, col] )
  rareCol <- names( pctNA[pctNA <= SPARSE.MIN] )   # usable sparse columns
  if ( length(rareCol) > 0 ) {
    rareData <- na.to.colMeans( x[, rareCol] )
    x[, rareCol] <- rareData
  }
  sparseCol <- names( pctNA[pctNA > SPARSE.MIN] )  # data too sparse to use
  dataSet <- x[, ! colnames( x ) %in% sparseCol]
  return( dataSet )
}

## ---- rem.single.val.col  ----
#' Remove single-valued columns from a data matrix
#' @description Remove single-valued (indicator) columns from a data frame
## Arguments
#' @param x   event data frame
#' @return Returns \code{x} without single-valued columns

rem.single.val.col <- function( x ) {
  singleValCol <- which( sapply( x, function(c) length(unique(c)) ) <= 1 )
  return( x[, -singleValCol] )
}

## ---- output.corr  ----
#' Plot and save correlation matrices and tables
#' @description Compute correlation matrices for indicator and numerical 
#'   variables by calling 
#'   \code{\link[=NS.CA.statUtils]{high.corr}}) and 
#'   \code{\link[=NS.CA.statUtils]{high.corr.df}})
#'   and save high correlation matrices to .csv files as data frames and tables
## Arguments
#' @param x   event data frame
#' @param indCol   indicator columns
#' @param minCor   high correlation threshold (defaults to 
#'   \code{\link[=NS.CA.modelUtils]{CORR.MIN}})
#' @param dir   directory into which .csv files will be stored 
#'   (defaults to "./")
#' @param corNumFile   file name prefix for numerical variable correlation 
#'   matrix (defaults to "CorNum_Prior_")
#' @param corNumTabFile   file name prefix for numerical variable correlation 
#'   table (defaults to "CorNum_PriorTable_")
#' @param corIndFile   file name prefix for indicator variable correlation 
#'   matrix (defaults to "CorInd_Prior_")
#' @param corIndTabFile   file name prefix for indicator variable correlation 
#'   matrix (defaults to "CorInd_PriorTable_")
#' @param corrPlotDir   directory for saving correlation matrix plots 
#'   (defaults to "./")
#' @param plotNumFile   file name prefix for the numerical predictor correlation 
#'   matrix (defaults to "Corr_Num_")
#' @param plotIndFile   file nam prefix for the indicator predictor correlation 
#'   matrix (defaults to "Corr_ind_")
#' @param timeStamp   file name identification timestamp 
#'   (defaults to \code{\link[=NS.CA.modelUtils]{TIMESTAMP}})
#' @param ...   additional arguments passed to
#'   \code{\link[=NS.CA.modelUtils]{auc.perf.base}}
#' @return Returns a data frame of highly correlated pairs of variables, 
#'   including their correlations:
#'   \item{var1}{1st variable in a highly correlated pair}
#'   \item{var2}{2nd variable in a highly correlated pair}
#'   \item{cor}{correlation betwen the two variables}

output.corr <- function( x, indCol, minCor=CORR.MIN, dir="./", 
                         corNumFile="CorNum_Prior_", 
                         corNumTabFile="CorNum_PriorTable_",
                         corIndFile="CorInd_Prior_",
                         corIndTabFile="CorInd_PriorTable_",
                         corrPlotDir="./", plotNumFile="Corr_Num_", 
                         plotIndFile="Corr_Ind_",
                         timeStamp=TIMESTAMP, ... ) {
  cDs <- colnames(x)
  plotNumCorrFile <- paste( corrPlotDir, plotNumFile, timeStamp, ".pdf", 
                            sep="" )
  hiCorPriorNum <- high.corr( x[, sort( cDs[which( !cDs %in% indCol )] )],
                              minCor, "Numerical factor correlation matrix", 
                              plotFile=plotNumCorrFile, ... )
  write.csv( hiCorPriorNum, paste( dir, corNumFile, timeStamp, ".csv", 
                                   sep="" ), row.names=F )
  hiCorNumDf <- high.corr.df( hiCorPriorNum, minCor )
  write.csv( hiCorNumDf, paste( dir, corNumTabFile, timeStamp, ".csv", 
                                sep="" ), row.names=F )

  plotIndCorrFile <- paste( corrPlotDir, plotIndFile, timeStamp, ".pdf", 
                            sep="" )
  hiCorPriorInd <- high.corr( x[, sort( indCol )], minCor,
                              "Indicator correlation matrix",
                              scaleArg=c( cex=0.75 ), 
                              plotFile=plotIndCorrFile, ... )
  write.csv( hiCorPriorInd, paste( dir, corIndFile, timeStamp, ".csv",
                                   sep="" ), row.names=F )
  hiCorIndDf <- high.corr.df( hiCorPriorInd, minCor )
  write.csv( hiCorIndDf, paste( dir, corIndTabFile, timeStamp, ".csv", 
                                sep="" ), row.names=F )
  hiCorDf <- rbind( hiCorIndDf, hiCorNumDf )
  return( hiCorDf )
}

## ---- run.glm.model  ----
#' Run the \code{glm} model, compute correlation matrices and tables
#' @description Run the model, compute correlation matrices for indicator and 
#'   numerical variables by calling 
#'   \code{\link[=NS.CA.statUtils]{high.corr}}) and 
#'   \code{\link[=NS.CA.statUtils]{high.corr.df}}),
#'   save high correlation matrices to .csv files as data frames and tables,
#'   save model coefficients as a table and compute and plot performance 
#'   statistics using \code{\link[=NS.CA.modelUtils]{perf.clsf.stat}})
## Arguments
#' @param x   event data frame
#' @param trainRows   rows of \code{x} belonging to the training data set
#' @param testRows   rows of \code{x} belonging to the test data set
#' @param inclCol   included columns
#' @param exclCol   excluded columns
#' @param statCol   name of the column of observed outcomes
#' @param uniOddsRatio   univariate odds ratio data frame containing columns
#'    \code{Variable, Odds.Ratio, Pr...z.. , CI.Lower, CI.Upper} and 
#'    \code{Validity} with row names the same as the values of \code{Variable}
#' @param numRec   total # of records in the original dataset
#' @param varJoiner   formula parameter for the \code{glm} model 
#'    (defaults to '+')
#' @param minCor   high correlation threshold (defaults to 
#'   \code{\link[=NS.CA.modelUtils]{CORR.MIN}})
#' @param scaleArg   label scaling (defaults to c( cex=1 ), i.e., full size)
#' @param threshold   percentage of high risk patients to select 
#'   (defaults to 0.05)
#' @param maxit   maximum number of iterations in the \code{glm} model 
#'   (defaults to 100)
#' @param sigLev   confidence level for testing the statistical significance of 
#'   coefficients (their difference from 0; defaults to 
#'   \code{\link[=NS.CA.modelUtils]{SIG.LEV}}))
#' @param trace   trace \code{glm} iterations? (defaults to TRUE)
#' @param trainText   graph title for performance plots for the training set
#'   (defaults to 'Training set AUC')
#' @param testText   graph title for performance plots for the text set
#'   (defaults to "")
#' @param oRdir   directory for saving odds ratios (defaults to "./")
#' @param oRfile   file name prefix for saving odds ratios 
#'   (defaults to "OR_All_")
#' @param coefDir   directory for saving model coefficients (defaults to "./")
#' @param coefFile   file name prefix for saving model coefficients
#'   (defaults to "Coef_All_")
#' @param corrPlotDir   directory into which correlation matrix plots will be 
#'   stored (defaults to "./")
#' @param trainAUCplotFile   file name prefix for saving training set AUC plots
#'   (defaults to "AUC_Train_")
#' @param testAUCplotFile   file name prefix for saving testing set AUC plots
#'   (defaults to "AUC_Test_")
#' @param corrPlotFile   file name prefix for saving the all-factor correlation 
#'   matrix plot (defaults to "Corr_Mat_All_")
#' @param timeStamp   file name identification timestamp 
#'   (defaults to \code{\link[=NS.CA.modelUtils]{TIMESTAMP}})
#' @param ...   additional arguments passed to
#'   \code{\link[=NS.CA.modelUtils]{auc.perf}} and 
#'   \code{\link[=NS.CA.modelUtils]{high.corr}}
#' @return Returns a data frame of risk statistics with row names corresponding 
#'   to patient data entries in \code{x} (see 
#'   \code{\link[=NS.CA.modelUtils]{perf.clsf.stat}}).

run.glm.model <- function( x, trainRows, testRows, inclCol, exclCol, statCol, 
                           uniOddsRatio, numRec, varJoiner='+', minCor=CORR.MIN, 
                           scaleArg=c( cex=0.6 ), threshold=0.05, maxit=100, 
                           sigLev=SIG.LEV, trace=T, 
                           trainText='Training set AUC', 
                           testText="Testing set AUC", oRdir="./", 
                           oRfile="OR_All_", coefDir="./", coefFile="Coef_All_", 
                           corrPlotDir="./", trainAUCplotFile="AUC_Train_", 
                           testAUCplotFile="AUC_Test_", 
                           corrPlotFile="Corr_Mat_All_", timeStamp=TIMESTAMP, 
                           ... ) {
  factorCol <- subset( inclCol, ! inclCol %in% exclCol )
  dataFact <- x[, factorCol]
  train <- dataFact[trainRows, ]
  plotAllFile <- paste( corrPlotDir, corrPlotFile, timeStamp, ".pdf", sep="" )
  hiCor <- high.corr( train[, sort( factorCol )], minCor,
                      "Factor correlation matrix", scaleArg=scaleArg, 
                      plotFile=plotAllFile, ... )
  if ( Reduce( '*', dim( hiCor ) ) > 0 ) {
    hiCorIndDf <- high.corr.df( hiCor, minCor )
  }

  statusCol <- which( colnames( dataFact ) %in% statCol )

  # test on the "odds ratio" training dataset

  fm <- glm( as.formula( paste( statCol, "~ .", sep="" ) ), train, 
             family='binomial', maxit=maxit, trace=trace )
  plotTrainFile <- paste( corrPlotDir, trainAUCplotFile, timeStamp, ".pdf", 
                          sep="" )
  trainGlm <- auc.perf( fm, train, train[, statusCol], type='response', 
                        text=trainText, plotFile=plotTrainFile, ... )
  
  plotTestFile <- paste( corrPlotDir, testAUCplotFile, timeStamp, ".pdf", 
                         sep="" )
  fullModel <- glm.test( dataFact, statusCol, testRows, threshold, trace=trace,
                         maxit=maxit, text=testText, varJoiner=varJoiner, 
                         plotFile=plotTestFile, ... )
  coefOut <- odds.ratio.stat( fullModel$model, uniOddsRatio, sigLev )
  write.csv( coefOut, paste( oRdir, oRfile, timeStamp, ".csv",
                             sep="" ), row.names=F )
  coefSummary <- coef( summary( fullModel$model ) )
  write.csv( coefSummary[order( rownames( coefSummary ) ), ],
             paste( coefDir, coefFile, timeStamp, ".csv", sep="" ) )

  # generate performance statistics

  prSort <- perf.clsf.stat( fullModel$perf$predicted, numRec,
                            dataFact[testRows, statusCol] )
  return( prSort )

}

## ---- ppv.sens.risk  ----
#' Plot and save the PPV / sensitivity graph and the risk matrix
#' @description Plot and save the standard PPV / sensitivity graph 
#'   \code{\link[=NS.CA.statUtils]{ppv.sens.plot}}) and save the risk matrix
## Arguments
#' @param x   event data frame
#' @param prSort   data frame of risk statistics with row names corresponding
#'   to patient data entries in \code{x} computed as a result of 
#'   \code{\link[=NS.CA.plotUtils]{test.odds.ratio}}) 
#' @param scenario   name of the scenario for which the data is saved 
#' @param idCol   ID column of \code{x} (defaults to 
#'   \code{\link[=NS.CA.modelUtils]{ID.COL}})
#' @param ppvSensText   graph title for the PPV / sensitivity plot
#' @param graphDir   directory for saving the PPV / sensitivity plot 
#'   (defaults to "./")
#' @param ppvFile   file name prefix for saving the PPV / sensitivity plot
#'   (defaults to "PPVsens_")
#' @param resultDir   directory for saving the risk file (defaults to "./")
#' @param riskFile   file name prefix for saving the risk file
#'   (defaults to "AllRisk_")
#' @param timeStamp   file name identification timestamp 
#'   (defaults to \code{\link[=NS.CA.modelUtils]{TIMESTAMP}})
#' @return Returns a data frame of risk statistics with row names corresponding 
#'   to patient data entries in \code{x} (see 
#'   \code{\link[=NS.CA.modelUtils]{perf.clsf.stat}}).


ppv.sens.risk <- function ( x, prSort, scenario, ppvSensText, idCol=ID.COL, 
                            graphDir="./", resultDir="./", ppvFile="PPV_Sens_", 
                            riskFile="AllRisk_", timeStamp=TIMESTAMP ) {
  g <- ppv.sens.plot( prSort, main=ppvSensText )
  print( g )
  ggsave( filename=paste( ppvFile, scenario, "_", timeStamp, ".pdf", sep="" ),
          path=graphDir, plot=g, width=11, height=8.5, units="in" )

  allRisk <- cbind( x[rownames( prSort ), idCol], prSort )
  colnames( allRisk )[1] <- idCol
  write.csv( allRisk, paste( resultDir, riskFile, timeStamp, ".csv",
                           sep="" ), row.names=F )
  return( allRisk )
}

## ---- lift.table.save  ----
#' Lift table and risk rankings for all and high-risk patients
#' @description Compute and save the lift table using 
#'   \code{\link[=NS.CA.statUtils]{lift.table}}) and save the risk matrices for 
#'   all and \code{topRiskNum} high-risk patients
## Arguments
#' @param prSort   data frame of risk statistics with row names corresponding
#'   to patient data entries in \code{x} computed as a result of 
#'   \code{\link[=NS.CA.plotUtils]{test.odds.ratio}}) 
#' @param nRec   total # of patients
#' @param dates   dates in the dataset 
#' @param today   calculation date
#' @param allRisk   data frame of PPV / sensitivity / lift statistics computed 
#'   as a result of \code{\link[=NS.CA.plotUtils]{ppv.sens.risk}}) 
#' @param steps   tabulation steps of lift statistics table (defaults to 
#'   c( 0.01, 0.05, 0.1, 0.2, 0.3, 0.5, 1 ))
#' @param nullHypStep   tabulation step corresponding to the null hypothesis 
#'   (benchmark algorithm; defaults to NA). If provided, is inserted into 
#'   \code{steps} and sorted
#' @param resultDir   directory for saving the files (defaults to "./")
#' @param liftFile   file name prefix for saving lift statistics
#'   (defaults to "Lift_")
#' @param liftThreshold   fraction of patients from the list to select 
#'   (defaults to 0.05)
#' @param riskFile   file name prefix for saving the risk rankings file
#'   (defaults to "HiRisk_")
#' @param topRiskNum   # of patients to select randomly from the high risk list 
#'   (defaults to 100)
#' @param topRiskFile   file name prefix for saving the top risk rankings file
#'   (defaults to "HiRiskRand_\code{topRiskNum}")
#' @param timeStamp   file name identification timestamp 
#'   (defaults to \code{\link[=NS.CA.modelUtils]{TIMESTAMP}})
#' @return No return parameter

lift.table.save <- function( prSort, nRec, dates, today, allRisk,
                             steps = c( 0.01, 0.05, 0.1, 0.2, 0.3, 0.5, 1 ),
                             nullHypStep=NA, resultDir="./", liftFile="Lift_",
                             liftThreshold=0.05,  riskFile="HiRisk_", 
                             topRiskNum=100, topRiskFile="HiRiskRand_",
                             timeStamp=TIMESTAMP ) {
  pctList <- sort( na.omit( c( steps, nullHypStep ) ) )
  liftTable <- lift.table( prSort, pctList, nRec )
  mostRecent <- which( dates == today )
  liftTable <- transform( liftTable, Num.Flagged.Most.Recent=
                            NS.CA.round( Pct.Total * length( mostRecent ) ) )
  write.csv( liftTable, paste( resultDir, liftFile, timeStamp, ".csv",
                             sep="" ), row.names=F )

  # top 5 %
  
  hiRisk <- head( allRisk, liftThreshold * nrow( prSort ) )
  write.csv( hiRisk, paste( resultDir, riskFile, timeStamp, ".csv", sep="" ),
             row.names=F )
  
  # random 100 from top 5%
  
  nHiRisk <- nrow( hiRisk )
  hiRiskSample <- hiRisk[sample( 1:nHiRisk, min( 100, nHiRisk ) ), ]
  write.csv( hiRiskSample[order( -hiRiskSample$Predicted ), ],
             paste( resultDir, topRiskFile, paste( topRiskNum, timeStamp, 
                                     sep="_" ), ".csv", sep="" ), row.names=F )
}
  
## ---- odds.ratio.save  ----
#' Combined indicator and numerical odds ratio
#' @description Compute and save indicator and numerical odds ratios using 
#'   \code{\link[=NS.CA.statUtils]{odds.ratio.summary}}) and
#'   \code{\link[=NS.CA.statUtils]{odds.ratio.num}}) 
## Arguments
#' @param x   event data frame
#' @param statCol   name of the column of observed outcomes
#' @param indCol   indicator columns
#' @param idCol   ID column of \code{x} (defaults to 
#'   \code{\link[=NS.CA.modelUtils]{ID.COL}})
#' @param addList   list of additional odds ratio tables (defaults to NA)
#' @param oRdir   directory for saving the odds ratio files (defaults to "./")
#' @param indORfile   file name prefix for saving the indicator odds ratio file
#'   (defaults to "ORind_")
#' @param uniORfile   file name prefix for saving the univariate odds ratio file
#'   (defaults to "ORuni_")
#' @param sigLev   confidence level for testing the statistical significance of 
#'   coefficients (their difference from 0; defaults to 
#'   \code{\link[=NS.CA.modelUtils]{SIG.LEV}}))
#' @param timeStamp   file name identification timestamp (defaults to 
#'   \code{\link[=NS.CA.modelUtils]{TIMESTAMP}})
#' @param ...   additional parameters passed to  
#'   \code{\link[=NS.CA.statUtils]{odds.ratio.matrix}})
#' @return Returns a data frame of univariate odds ratios:
#'   \item{Variable}{variable name}
#'   \item{Odds.Ratio}{univariate odds ratio}
#'   \item{Std..Error}{standard error[ ln(odds ratio) ]}
#'   \item{Pr...z..}{probability of z.value exceeeding the significance level}
#'   \item{CI.Lower}{lower confidence interval boundary of odds ratio}
#'   \item{CI.Upper}{upper confidence interval boundary of odds ratio}
#'   \item{Validity}{statistical significance marker ('*' = valid)}

odds.ratio.save <- function( x, statCol, indCol, idCol=ID.COL, addList=NA,  
                             oRdir=".", indORfile="ORind_", uniORfile="ORuni_",
                             sigLev=SIG.LEV, timeStamp=TIMESTAMP, ... ) {

  status <- unlist( x[, statCol] )

  oRi <- odds.ratio.matrix( x, status, indCol, level=sigLev, ... )
  oRind <- odds.ratio.summary( oRi, x, statCol )
  write.csv( oRind, paste( oRdir, indORfile, timeStamp, ".csv", sep="" ),
             row.names=F )

  # numeric odds ratio

  nc <- colnames( x[, !colnames( x ) %in% c( indCol, idCol, statCol )] )
  numCol <- nc[sapply( x[, nc], is.numeric )]
  oddsRatioNum <- odds.ratio.num( x, status, numCol, level=sigLev )

  # combined univariate ratio

  uniOutCol <- c( "Variable", "Odds.Ratio", "Pr...z..", "CI.Lower", "CI.Upper",
                  "Validity" )
  oRn <- transform( oddsRatioNum, Variable=rownames( oddsRatioNum ) )

  addNoNA <- addList[! is.na( addList )]   # na.omit doesn't work here!
  rbindList <- c( list( oRind[oRind$Variable != "TOTAL", uniOutCol], 
                        oRn[, uniOutCol] ),
                  lapply( addNoNA, function( x ) x[, uniOutCol] ) )                  
  uniOddsRatio <- Reduce( rbind, rbindList )
  write.csv( uniOddsRatio, paste( oRdir, uniORfile, timeStamp, ".csv", sep="" ), 
             row.names=F )
  
  return( uniOddsRatio )
}

## ---- charge.save  ----
#' Charges for predicted hospitalizations
#' @description Compute and save charges for specific and general 
#'   hospitalizations
## Arguments
#' @param risk   data frame of computed and actual risk data ordered by 
#'   predicted probabilities of outcome of interest in descending order. It 
#'   should contain (at least) the following columns:
#'   \describe{
#'     \item{idCol}{identification column (key; defaults to 
#'       \code{\link[=NS.CA.modelUtils]{ID.COL}}})
#'     \item{predCol}{predicted outcome column}
#'     \item{actCol}{actual outcome column}
#'   }
#' @param x   event data frame including charges
#' @param chargeCol   column(s) of charges in \code{x}
#' @param idCol   ID column of \code{x} (defaults to 
#'   \code{\link[=NS.CA.modelUtils]{ID.COL}})
#' @param predCol   column(s) of predicted probabilities of outcome of interest
#'   (defaults to \code{\link[=NS.CA.modelUtils]{PRED.COL}})
#' @param actCol   column(s) of actual outcomes of interest (defaults to 
#'   \code{\link[=NS.CA.modelUtils]{ACT.COL}})
#' @param chargeDir   directory for saving the charge file (defaults to "./")
#' @param chargeFile   file name prefix for saving the charge file
#'   (defaults to "Chrg_")
#' @param timeStamp   file name identification timestamp (defaults to 
#'   \code{\link[=NS.CA.modelUtils]{TIMESTAMP}})
#' @return Returns a data frame of mean charges per row of \code{x} (patient) 
#'   with \code{chargeCol} columns

charge.save <- function( risk, x, chargeCol, idCol=ID.COL, predCol=PRED.COL, 
                         actCol=ACT.COL, chargeDir=".", chargeFile="Chrg_",
                         timeStamp=TIMESTAMP ) {
  chargeArg <- Reduce( function( ... ) paste( ..., sep="," ), chargeCol )
  chargeForm <- as.formula( paste( "cbind(", chargeArg, ") ~", idCol ) )
  charge <- aggregate( chargeForm, data=x, FUN="sum" )
  chargeSummary <- merge( risk[, c( idCol, predCol, actCol )], 
                          x[, c( idCol, chargeCol )], by=idCol, all.x=T )
  meanChg <- colSums( chargeSummary[, chargeCol], na.rm=T ) / 
    nrow( chargeSummary )
  mChg <- data.frame( t( meanChg ) )
  write.csv( mChg, paste( chargeDir, chargeFile, timeStamp, ".csv", sep="" ), 
             row.names=F )
  return( mChg )
}

## ---- model.comp  ----
#' Compare two models by performance and charges
#' @description Compare performance of two models, compute and save respective 
#'   patients' charges
## Arguments
#' @param altPred   data frame of computed pronbabilities of outcome of interest
#'   and actual outcome(s). It should contain 
#'   (at least) the following columns:
#'   \describe{
#'     \item{idCol}{identification column (key; defaults to 
#'       \code{\link[=NS.CA.modelUtils]{ID.COL}}})
#'     \item{outcomes}{outcome column(s)}
#'   }
#' @param x   event data frame including charges
#' @param outCol   vector of columns containing outcomes
#' @param outInd   outcome(s) of interest index(indices)
#' @param chargeCol   column(s) of charges in \code{x}
#' @param idCol   ID column of \code{x} (defaults to 
#'   \code{\link[=NS.CA.modelUtils]{ID.COL}})
#' @param predCol   column(s) of predicted probabilities of outcome of interest
#'   (defaults to \code{\link[=NS.CA.modelUtils]{PRED.COL}})
#' @param nRows   number of entries in \code{x} (patients) selected for 
#'   comparison
#' @param aucText   performance plot caption (defaults to "Original model")
#' @param chargeDir   directory for saving the charge file (defaults to "./")
#' @param chargeFile   file name prefix for saving the charge file
#'   (defaults to "ChrgOM_")
#' @param perfFile   file name prefix for saving the performance and charge file
#'   (defaults to "PerfOM_")
#' @param timeStamp   file name identification timestamp (defaults to 
#'   \code{\link[=NS.CA.modelUtils]{TIMESTAMP}})
#' @param ...   additional arguments passed to
#'   \code{\link[=NS.CA.modelUtils]{auc.perf.base}}
#' @return Returns a data frame of mean charges per row of \code{x} (patient) 
#'   with the following columns
#'   \item{\code{outCol}}{outcome column(s)}
#'   \item{\code{chargeCol}}{charge columns}

model.comp <- function( altPred, x, outCol, outInd, chargeCol, idCol=ID.COL, 
                        predCol=PRED.COL, nRows=1000, aucText="Original model", 
                        chargeDir=".", chargeFile="ChrgOM_", perfFile="PerfOM_",
                        timeStamp=TIMESTAMP, ... ) {
  mSummary <- merge( x[, c( idCol, outCol )], altPred[, c( idCol, predCol )], 
                     by=ID.COL, all.x=T )
  mPerf <- auc.perf.base( mSummary[, predCol], mSummary[, outCol[outInd]], 
                          text=aucText, ... )
  mSort <- mSummary[order( -mSummary[, predCol] ), ]
  mPPV <- colSums( mSort[1:nRows, outCol] ) / nRows
  mChg <- charge.save( mSort[1:nRows, ], x, chargeCol, predCol=predCol, 
                       actCol=outCol[outInd], chargeDir=chargeDir, 
                       chargeFile=chargeFile, timeStamp=timeStamp )
  auc <- unlist( mPerf$auc@y.values ) 
  mPchg <- data.frame( cbind( data.frame( t( mPPV ), mChg, AUC=auc ) ) )
  write.csv( mPchg, paste( chargeDir, perfFile, timeStamp, ".csv", sep="" ), 
             row.names=F )
  return ( mPchg )
}

## ---- surv.diff  ----
#' Survival time
#' @description Compute survival time as the number of days from the start of 
#'   the observation interval to the minimum of outcome date and interval end
## Arguments
#' @param asOfDate   date stamp of the beginning of the interval
#' @param today   maximum survival date (today's date)
#' @param outcomeDate   date stamp of the end of the interval
#' @param fmt   date format (defaults to "\%m/\%d/\%Y")
#' @return Returns the difference in days (integer) between \code{asOfDate} and
#'   \code{min(outcomeDate, today)}

surv.diff <- function( asOfDate, today, outcomeDate, fmt="%m/%d/%Y" ) {
  dtEnd <- as.Date( strptime( outcomeDate, fmt ) )
  dtEnd[ is.na( dtEnd )] <- today
  return( as.integer( dtEnd - asOfDate ) )
}

## ---- run.cox.model  ----
#' Run the \code{coxph} (Cox) model and compute its performance metrics
#' @description Run the Cox model and compute its performance metrics by calling 
#'   \code{\link[=NS.CA.modelUtils]{auc.perf}}) and 
#'   \code{\link[=NS.CA.modelUtils]{perf.clsf.stat}})
## Arguments
#' @param train   training dataset
#' @param test   testing dataset
#' @param today   valuation date
#' @param inclCol   included columns
#' @param exclCol   excluded columns
#' @param statCol   name of the column of observed outcomes
#' @param dDateCol  outcome date column (defaults to "DEATH_DATE")
#' @param aDateCol  as-of date column (defaults to "AS_OF_DATE")
#' @param varJoiner   formula parameter for the \code{glm} model 
#'    (defaults to '+')
#' @param maxIter   max # of iterations for \code{coxph} 
#'   (defaults to \code{\link[=NS.CA.modelUtils]{MAX.ITER}})
#' @param coefDir   directory for saving model coefficients (defaults to "./")
#' @param coefFile   file name prefix for saving model coefficients
#'   (defaults to "Coef_All_")
#' @param plotDir   directory for saving AUC plot files (defaults to "./")
#' @param plotFile   file name prefix for saving AUC plot files
#'   (defaults to "Cox_AUC_")
#' @param text   graph caption (defaults to "Cox survival model analysis")
#' @param timeStamp   file name identification timestamp 
#'   (defaults to \code{\link[=NS.CA.modelUtils]{TIMESTAMP}})
#' @param ...   additional arguments passed to
#'   \code{\link[=NS.CA.modelUtils]{auc.perf}}
#' @return Returns a data frame of risk statistics with row names corresponding 
#'   to patient data entries in \code{x} (see 
#'   \code{\link[=NS.CA.modelUtils]{perf.clsf.stat}}).

run.cox.model <- function( train, test, today, inclCol, exclCol, statCol, 
                           dDateCol="DEATH_DATE", aDateCol="AS_OF_DATE",
                           varJoiner='+', maxIter=COX.ITER.MAX, coefDir=".", 
                           coefFile="Coef_All_Cox_", plotDir=".", 
                           plotFile="Cox_AUC_", 
                           text="Cox survival model analysis",
                           timeStamp=TIMESTAMP, ... ) {
  survTrain <- surv.diff( train[, aDateCol], today, train[, dDateCol] )
  survCurve <- Surv( survTrain, train[, statCol] )
  factorCol <- subset( inclCol, ! inclCol %in% c( exclCol, statCol ) )
  formPredStr <- paste( factorCol, collapse=varJoiner )
  formSurv <- as.formula( paste( "survCurve ~", formPredStr ) )

  coxFit <- coxph( formSurv, data = train, 
                   control=coxph.control( iter.max=maxIter ) ) 
  coefSummaryCox <- coef( summary( coxFit ) )
  write.csv( coefSummaryCox[order( rownames( coefSummaryCox ) ), ],
             paste( coefDir, coefFile, timeStamp, ".csv", sep="" ) )

  survFit <- survfit( coxFit, newdata=test )
  predTest <- summary( survFit )$table[, "0.95LCL"]
  
  survTest <- surv.diff( test[, aDateCol], today, test[, dDateCol] )
  predAnalysis <- data.frame( predicted=predTest, actual=survTest, 
                              status=test[, statCol], 
                              As.Of.Date=test[, aDateCol] )

  plotCoxFile <- paste( plotDir, plotFile, timeStamp, ".pdf", sep="" )
  predPerf <- with( predAnalysis, 
                    auc.perf( coxFit, test, test[, statCol], type='risk', 
                              text=text, plotFile= plotCoxFile, ... ) )

  prSortCox <- perf.clsf.stat( predPerf$predicted, nrow( test ), 
                               test[, statCol] )
  
  return( prSortCox )
}
