#' NS.CA.dateUtils.
#'
#' Date manipulation and date arithmetic
#'
#' @name NS.CA.dateUtils
#' @docType package
NULL
