#' NS.CA.dateUtils.
#'
#' Date manipulation and date arithmetic
#'
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @name NS.CA.dateUtils
#' @docType package
NULL
