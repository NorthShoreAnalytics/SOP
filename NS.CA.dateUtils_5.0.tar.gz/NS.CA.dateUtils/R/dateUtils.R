## ---- days.in.year.Date ----
#' Calculate the # of days in a given year forward or backward
## Arguments
#' @param dt   current date
#' @param   direction   count forward (>0) or backward(<0)
#' @return   (integer) # of days in the year


days.in.year.Date <- function( dt, direction=1 ) {
  int <- ifelse( direction > 0, '1 year', '-1 year' )
  return( as.integer( abs( seq.Date( dt, length.out=2, by=int )[2] - dt ) ) )
}

## ---- year.frac.Date ----
#' Calculate time interval between two dates as a fraction of the year
## Arguments
#' @param dt1   start date
#' @param dt2   end date
#' @return (numeric) fraction of the year

year.frac.Date <- function( dt1, dt2 ) {
  dirn <- as.numeric( sign( dt2-dt1 ) )
  diffT <- Reduce( '+', lapply( seq.Date( dt1, dt2, by=paste( sign( dt2-dt1 ),
                                                          'year' ) ),
                             function( d ) {
                               dd <- as.numeric( dt2-d )
                               diy <- days.in.year.Date( d, dd )
                               sign( dt2-dt1 )*as.numeric( min( abs( dd ), diy ) /
                                                          as.integer( diy ) )
                             }
                            )
                 )
  return( as.numeric( diffT ) )
}

## ---- yy.to.yyyy ----
#' 2-digit year to 4-digit year
## Arguments
#' @param x   array of dates
#' @param cutoff   year of the century beyond which conversion is upward (i.e.,
#'   "51" converts to 2051)
#' @return Returns dates with 2-digit years converted to 4-digit years:
#' years below cutoff are converted to the current century, otherwise go to
#' previous century

yy.to.yyyy <- function( x, cutoff=50 ) {
  thisCentury <- floor( as.numeric( format( Sys.Date(), "%Y" ) ) / 100 )
  y <- as.numeric( format( x, "%Y" ) )
  yyInd <- which( y / 100 < 1 )
  yyCurInd <- which( y[yyInd] <= cutoff )
  y[yyInd][ yyCurInd] <-  y[yyInd][yyCurInd] +  thisCentury    * 100
  y[yyInd][-yyCurInd] <-  y[yyInd][yyCurInd] + ( thisCentury-1 ) * 100

  yStr <- paste( y, format( x, "%m" ), format( x, "%d" ), sep="-" )
  y <- as.Date( yStr )
  return( y )
}

## ---- first.date ----
#' Earliest date by row from data frame columns
## Arguments
#' @param x   data frame of dates
#' @param cutoff   dates before that time are set to the minimum date
#'   defaults to Sys.Date() - 120 years
#' @return Returns a list of earliest dates in each row

first.date <- function( x, cutoff=Sys.Date() - as.difftime(6240,
                                                           units="weeks" ) ) {
  d1 <- data.frame( sapply( x, as.timeDate ) )
  return( pmax( as.Date( apply(d1,1,min, na.rm=T ) ), cutoff ) )
}


## ---- first.valid.date ----
#' First non-na date by row from data frame columns
## Arguments
#' @param x   data frame of dates
#' @param dateNow   cutoff date
#' @param op   comparison operator for cutoff
#' @param fn   aggregate function for cutoff
#' @return Returns a list of earliest valid dates in each row

first.valid.date <- function( x, dateNow = as.Date( "1970-01-01" ), op=`<=`,
                              fn=min ) {
  y <- data.frame( lapply( x, as.Date, "%Y-%m-%d" ) )
  ci <- apply( !is.na( y ) & data.frame( lapply( y, op, dateNow ) ), 1, which )
  colInd <- which( sapply( ci, length ) > 0 )
  fd <- rep( NA, length( ci ) )
  fd[colInd] <- lapply( colInd, function( i ) Reduce( fn, y[i, ci[[i]]] ) )
  fRes <- Reduce( 'c', fd )
  return( fRes )
}


## ---- timestamp.from.date ----
#' Date to timestamp
#' @description Converts a date to timestamp in the form of
#' [yyyy][sep][mm][sep][dd]
## Arguments
#' @param d   date (defaults to \code{link{Sys.Date}})
#' @param sep   year-month-day separator (defaults to "_")
#' @return   Returns a timestamp string in the form of [yyyy][sep][mm][sep][dd]

timestamp.from.date <- function( d=Sys.Date(), sep="_" ) {
  return( paste( year( d ), sprintf( "%02d", month( d ) ),
                sprintf( "%02d", day( d ) ), sep=sep ) )
}


## ---- date.ind ----
#' Date to date components
#' @description Appends the following columns to a data frame containing a date:
#' \describe{
#'   \item{day of the week}{}
#'   \item{day of the year}{}
#'   \item{month}{}
#'   \item{hour}{}
#'   \item{year}{}
#'   \item{date index in sequence}{}
#'   \item{ISO date (YYYY-MM-DD)}{}
#'   }
## Arguments
#' @param x   data frame containing a date column 
#' @param col   date column in \code{x}
#' @return   Returns the original data frame with date element columns appended


date.ind <- function( x, col ) {
  di <- transform( x, dayOfWeek = as.integer( format( x[, col], '%w' ) ),
                   dayOfYear = as.integer( format( x[, col], '%j' ) ),
                   month = as.integer( format( x[, col], '%m' ) ),
                   hour = as.integer( format( x[, col], '%H' ) ),
                   year = as.integer( format( x[, col], '%Y' ) ),
                   date = as.Date( format( x[, col], "%Y-%m-%d" ) ) )
  res <- transform( di, dateIndex = dayOfYear + ( year - min( year ) ) * 
                      max( dayOfYear ) )
  return( res )
}

## ---- season.calendar.map ----
#' Month-to-season map
#' @description Generates a map of months to the names of calendar seasons
#' @return   Returns a map in the form of "season name" -> vector of month #'s

season.calendar.map <- function( ) {
  return( list( winter=c( 12,1,2 ), spring=c( 3,4,5 ),
                summer=c( 6,7,8 ), fall=c( 9,10,11 ) ) )
}

## ---- season.from.month ----
#' Season from month
#' @param month   month(s) of the year (can be a list)
#' @return   Returns a list of seasons corresponding to \code{month(s)}

season.from.month <- function( month ) {
  map <- list.invert( season.calendar.map() )
  return( sapply( as.list( month ), function( m ) map[[m]] ) )
}

## ---- season.subset ----
#' Get entries from the given season
#' @description Given the name of a season, get the rows of a data that belong 
#'   to this season
## Arguments
#' @param x   data frame
#' @param season   name of the season
#' @param field   name of the field containing the month of the corresponding 
#'   date or timestamp
#' @param seasonMap   mapping function for seasons (defaults to 
#'   \code{\link[=NS.CA.dateUtils]{season.calendar.map}})))
#' @return   Returns the data frame containing only the rows from \code{season}


season.subset <- function ( x, season, field="month", 
                            seasonMap=season.calendar.map ) {
  sm <- seasonMap()
  res <- c( list( all=sort( Reduce( 'c', sm ) ) ), sm )
  return( x[x[, field] %in% res[[season]], ] )
}

## ---- dow.map ----
#' Day-of-the week map
#' @description Generates a map of days of the week to their three-letter names
#' @return   Returns a map in the form of "3-letter day name" -> day # 
#'   starting at Sun=0

dow.map <- function( ) {
  return( list( Sun=0, Mon=1, Tue=2, Wed=3, Thu=4, Fri=5, Sat=6 ) )
}

## ---- hours ----
#' Difference between two timestamps in hours
## Arguments
#' @param t1   start date
#' @param t2   end date
#' @return   Returns the difference between \code{t1} and \code{t2} in hours

hours <- function( t1, t2 ) {
  return( as.numeric( difftime( t1, t2, units="hours" ) ) )
}

## ---- dec.to.hr ----
#' Decimal timestamp to a string containing hours, minutes and seconds
#' @description Converts a decimal date in the form YYYYMMDD.hhmmss to a string 
#'   in the form of "hh hr( s ) mm min ss sec"
## Arguments
#' @param x   timestamp in decimal form 
#' @return   Returns a string in the form of "hh hr( s ) mm min ss sec"


dec.to.hr.str <- function( x ) {
  hr <- floor( x )
  min <- floor( ( x - hr ) * 60 )
  sec <- round( ( x - hr - min/60 ) * 3600, 0 )
  return( paste( hr, "hr( s )", min, "min", sec, "sec" ) ) 
}

## ---- weekdays ----
#' One-letter weekday names
#' @description Generates a sequence of one-letter weekday names ("U" - "S") or 
#'   a one-letter name corresponding to the # of a day of the week (0 - 6)
## Arguments
#' @param x   (optional) # of a day of the week
#' @return   Returns:
#'   \item{if no \code{x} is supplied,}{"U", "M", "T", "W", "R", "F", "S"}
#'   \item{if \code{x} is supplied,}{one-letter name of the \code{x}-th day of 
#'     the week}

weekdays <- function( x ) {
  wd <- c( "U", "M", "T", "W", "R", "F", "S" )
  res <- NA
  if ( ! missing( x ) )  {
    res <- wd[x]
  }
  else {
    res <- wd
  }
  return( res ) 
}

## ---- hours24 ----
#' Hours of the day
#' @return   Returns whole numbers from 0 to 23 

hours24 <- function() { 0:23 }

## ---- mark.hr ----
#' Hourly time marks
#' @description Generates a sequence of integer time marks corresponding to 
#'   hours of the day by day of the week
## Arguments
#' @param dow   vector of weekday #'s (defaults to 0:6, where "0" is Sunday)
#' @param hr   vector of hours of the day (defaults to 0:23)
#' @return   Returns a list of nonnegative whole numbers signifying consecutive 
#'   hour marks for the given hours of given days of the week (defaults to 0:23)

mark.hr <- function( dow=0:6, hr=0:23 ) {
  return( 0:( length( dow ) * length( hr ) - 1 ) )
}

## ---- date.hr.seq ----
#' Date and hour time marks
#' @description Generates an ordered sequence of dates and corresponding time 
#'   marks
## Arguments
#' @param dateFrom   start date of the sequence
#' @param dateTo   end date of the sequence
#' @param seqFn   function generating daily time marks (defaults to 
#'   \code{\link[=NS.CA.dateUtils]{hours.24}})
#' @param colNames   column names of the resulting data frame (defaults to 
#'   \code{c( "date", "hour" )})
#' @param ...   further arguments passed to \code{seqFn}
#' @return   Returns a data frame with dates as the first column and subday time 
#'   marks as subsequent columns ordered right to left (e.g., by hour, then by 
#'   date)

date.hr.seq <- function( dateFrom, dateTo, seqFn=hours24, 
                         colNames=c( "date", "hour" ), ... ) {
  dateHr <- setNames( merge( seq(dateFrom, dateTo, by='1 day'), seqFn( ... ) ),
                      colNames )
  return( dateHr[do.call( order, as.list( dateHr ) ), ] )
}

## ---- mark.from.day.hr ----
#' Convert numeric weekday and hour to hourly time mark
## Arguments
#' @param d  (numeric) day of the week
#' @param h  hour
#' @return   Returns a time mark 
#'   \code{=24*d + h; 0 <= mark <= 167}

mark.from.day.hr <- function( d, h ) {
  return( d * 24 + h )
}


## ---- mark.from.date.hr ----
#' Convert date and hour to hourly time mark 
#'   (by calling \code{\link[=NS.CA.dateUtils]{mark.from.day.hr}})
## Arguments
#' @param d  date
#' @param h  hour
#' @return   Returns a time mark 
#'   \code{=24 * ( wday( d ) - 1 ) + h; 0 <= mark <= 167}

mark.from.date.hr <- function( d, h ) {
  return( mark.from.day.hr( wday( d ) - 1, h ) )
}

## ---- mark.from.date ----
#' Convert a date to hourly time mark 
#'   (by calling \code{\link[=NS.CA.dateUtils]{mark.from.date.hr}})
## Arguments
#' @param d  date
#' @return   Returns a time mark 
#'   \code{=24*wday( d ) + hour( d ); 0 <= mark <= 167}

mark.from.date <- function( d ) {
  return( mark.from.date.hr( as.Date( d ),  hour( d ) ) )
}

## ---- mark.add ----
#' Intelligently add to time mark
## Arguments
#' @param m  time mark
#' @param dm   marks to ad to \code{m}
#' @param mSet   available marks 
#'   (defaults to the result of \code{\link[=NS.CA.dateUtils]{mark.hr()}}))
#' @return   Returns a time mark 
#'   \code{=24*wday( d ) + hour( d ); 0 <= mark <= 167}

mark.add <- function( m, dm, mSet=mark.hr() ) {
  return( ( m + dm ) %% ( max( mSet ) + 1 ) + min( mSet ) )
}


## ---- random.date ----
#' Generate random dates within a given range 
## Arguments
#' @param dateFrom   interval start
#' @param dateTo   interval end
#' @param startFrac   starting point of the interval 
#'   (between 0 and 1; defaults to 0)
#' @param n   number of dates to generate (defaults to 1)
#' @return   Returns \code{n} random dates between 
#'   \code{dateFrom + ( dateTo - dateFrom ) * startFrac} and \code{dateTo}

random.date <- function( dateFrom, dateTo, startFrac=0, n=1 ) {
  dFrom <- dateFrom + ( dateTo - dateFrom ) * startFrac
  return( sort( dFrom + ( dateTo - dFrom ) * runif( n ) ) )
}

## ---- date.to.POSIXct ----
#' convert \code{Date} to \code{POSIXct}
## Arguments
#' @param d   Date
#' @param format   format of \code{d} (defaults to "\%F")
#' @param tz   time zone (defaults to "UTC")
#' @return   Returns a \code{POSIXct} object

date.to.POSIXct <- function( d, format="%F", tz="UTC" ) {
  return( as.POSIXct( strptime( as.character( d ), format, tz ) ) )
}
