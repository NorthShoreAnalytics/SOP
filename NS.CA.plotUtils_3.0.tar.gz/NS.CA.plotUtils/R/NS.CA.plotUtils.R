#' NS.CA.plotUtils
#'
#' Functions for graphing (predictive) model performance metrics and statistics
#' and functional dependencies for model data
#'
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @name NS.CA.plotUtils
#' @docType package
NULL
