## ---- two.ord.plot  ----
#' Two-ordinate PPV and Sensitivity plot
#' @description Plots a two-ordinate PPV and Sensitivity plot using
#'   plotrix:twoord.plot
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param x  model performance data frame
#' @param xCol   abscissa column in x (defaults to "Percent.Flagged")
#' @param ly   left ordinate in x (defaults to "PPV")
#' @param ry   right ordinate in x (defaults to "Sensitivity")
#' @param xlab   asbcissa label (defaults to "Percentage of patients flagged")
#' @param xTickSeq   tick sequence (defaults to \code{seq( 0, 1, by=0.1 )})
#' @param lyTickSeq   left oridante tick sequence (defaults to
#'   \code{seq( 0, 1, by=0.05 )})
#' @param ryTickSeq   right oridante tick sequence (defaults to lyTickSeq)
#' @param ylab   left ordinate label (defaults to "Positive predictive value")
#' @param rylab   right ordinate label (defaults to "Sensitivity")
#' @param lcol   left ordinate color (defaults to "red")
#' @param rcol   right ordinate color (defaults to "blue")
#' @param main   plot title (defaults to "PPV / Sensitivity")
#' @param type   plot type (defaults to 'l')
#' @param do.first   plot oprations performed before plotting the curves
#'   (defaults to "grid(col='black',lty='dotted')")
#' @param ...   additional parameters passed to twoord.plot
#' @return None

two.ord.plot <- function( x, xCol="Percent.Flagged", ly="PPV", ry="Sensitivity",
                          xlab="Percentage of patients flagged",
                          xTickSeq=seq( 0, 1, by=0.1 ),
                          lyTickSeq=seq( 0, 1, by=0.05 ),
                          ryTickSeq=xTickSeq,
                          ylab="Positive predictive value",
                          rylab="Sensitivity", lcol="red", rcol="blue",
                          main="PPV / Sensitivity", type='l',
                          do.first="grid(ny=NA, col='black',lty='dotted')",
                          ... ) {
  ylab.at <- 0.5 * (max( x[, ly] ) - min( x[, ly] ))
  twoord.plot( lx=xCol, ly=ly, rx=xCol, ry=ry, data=x, xlab=xlab,
               xtickpos=xTickSeq, xticklab=percent( xTickSeq ),
               lytickpos=lyTickSeq, rytickpos=ryTickSeq, ylab=ylab,
               ylab.at=ylab.at, rylab=rylab,
               lcol=lcol, rcol=rcol, main=main, type=type, do.first=do.first,
               ... )
}

## ---- ppv.sense.plot  ----
#' PPV and Sensitivity plot
#' @description Plots a PPV and Sensitivity plot using ggplot
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param x  model performance data frame
#' @param xCol   abscissa column in x (defaults to "Percent.Flagged")
#' @param ppvCol   positive predictive value (PPV) column in x (defaults to
#'   "PPV")
#' @param sensCol   sensitivity column (defaults to "Sensitivity")
#' @param xTickSeq   abscissa tick sequence (defaults to
#'   \code{seq( 0, 1, by=0.1 )})
#' @param yTickSeq   ordinate tick sequence (defaults to \code{xTickSeq})
#' @param main   plot title (defaults to "PPV / Sensitivity")
#' @param ...   additional parameters passed to twoord.plot
#' @return ggplot object

ppv.sens.plot <- function( x, xCol="Percent.Flagged", ppvCol="PPV",
                           sensCol="Sensitivity",
                           xTickSeq = seq( 0, 1, by=0.1 ), yTickSeq=xTickSeq,
                           main="Model performance metrics" ) {
  prPlot <- rbind( data.frame( Pct=x[, xCol], Value=x[, ppvCol], Type="PPV" ),
                   data.frame( Pct=x[, xCol], Value=x[, sensCol],
                               Type="Sensitivity" ) )
  g <- ggplot( prPlot, aes( x=Pct, y=Value, colour=Type ) ) +
    geom_line( aes( group=Type ), size=1 ) +
    labs( title=main, x="Proportion of patients flagged",
          y="Positive predictive value / Sensitivity" ) +
    scale_x_continuous( breaks = xTickSeq, labels=percent ) +
    scale_y_continuous( breaks = yTickSeq, labels=percent ) +
    theme( axis.text = element_text( size=11, colour="black", face="bold" ),
           title = element_text( size=12, colour = "black", face="bold",
                               vjust=0.12 ),
           panel.grid.major=element_line(colour="black", linetype="dotted"),
           panel.background=element_blank(),
           legend.position="bottom" ) +
    guides( colour=guide_legend( nrow=1, title="Performance metrics",
                                 title.position="top", title.hjust=0.5 ) )

    return( g )
}


## ---- y.tick  ----
#' Y axis ticks
#' @description Given a data vector, generates a sequence from min to max with 
#'   a given step
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param y   numeric vector
#' @param yStep   tick step
#' @param round   data rounding flag (defaults to T)
#' @return Returns a sequence of #'s from \code{min(y)} to \code{max(y)} with a 
#'   step of \code{yStep}

y.tick <- function( y, yStep, round=T ) {
  ym <- min( y ):max( y )
  if ( round ) {
    ym <- round( ym, 0 )
  }
  yInd <- ( ( 1:length( ym ) ) - 1 ) %% yStep == 0
  return( ym[yInd] )
}

## ---- y.scale  ----
#' Y axis scaling
#' @description Given a data frame, generates ticks for the y-axis and scales 
#'   the graph using \code{\link[=NS.CA.plotUtils]{y.tick}}
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param x   data frame
#' @param col   column of \code{x} to be graphed
#' @param scale   scaling vector in the form of c(min, max) to be passed to 
#'   \code{\link[=ggplot]{ggplot}} as y-axis limits
#' @param step   tick step
#' @param minCol   column of \code{x} containing minimum differences 
#'   (defaults to \code{qDiffmin})
#' @param maxCol   column of \code{x} containing maximum differences
#'   (defaults to \code{qDiffMax})
#' @param absOut   name of the output element of the scale list containing 
#'   absolute values (defaults to \code{abs})
#' @param diffOut   name of the output element of the scale list containing 
#'   differences from the benchmark (defaults to \code{diff})
#' @param outNames   vector of names for the output element \code{scale}
#'   (defaults to \code{c( absOut, diffOut )})
#' @return Returns 
#'   \item{yTickSeq}{tick sequence for the y-axis}
#'   \item{scale}{list of two-element vectors of min and max absolute values and 
#'     differences}

y.scale <- function( x, col, scale, step, minCol="qDiffMin", maxCol="qDiffMax",
                     absOut="abs", diffOut="diff", 
                     outNames=c( absOut, diffOut ) ) {
  yTs <- lapply( scale, function( x ) min( x ) : max( x ) )
  if ( length( scale ) == 0 ) {
    scales <- list()
    minX <- min( x[, col] )
    maxX <- max( x[, col] )
    minDiff <- min( x[, minCol] )
    maxDiff <- max( x[, maxCol] )
    scale[[absOut]] <- c( minX, maxX )  
    scale[[diffOut]] <- c( min( x[, minCol] ), max( x[, maxCol] ) ) 
    yTs <- list( seq(  minX, maxX, step ), seq( minDiff, maxDiff, step ) )
    names( yTs ) <- outNames
  }
  yTickSeq <- lapply( yTs, y.tick, step )
  return( list( yTickSeq=yTickSeq, scale=scale ) )
}

## ---- title.plot  ----
#' Plot title generator
#' @description Generates a plot title from the base title string, pavilion, 
#'   season, date boundaries, quantile and modified acuity 
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param t   base title string
#' @param pavilion   pavilion
#' @param season   season
#' @param dateFrom   starting date
#' @param dateTo   end date
#' @param quantile   vector of quantiles of interest
#' @param acute   modified acuity
#' @return Returns an enhanced plot tile as a string

title.plot <- function ( t, pavilion, season, dateFrom, dateTo, quantile, 
                         acute ) {
  return( paste( t, ", pavilion=", pavilion, "\n season=", season, "; from", 
                 dateFrom, "to", dateTo, "; quantile levels=", 
                 Reduce( function( ... ) paste( ..., sep=", " ), quantile ),
                 "; acute=", acute ) )
}

## ---- legend.quantile  ----
#' Quantile legend generator
#' @description Generates quantile legend 
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param quantile   vector of quantiles of interest (can be of length 1)
#' @param shift   how many intervals to exclude from the legend (defaults to 1; 
#'   used mainly for compatibility with \code{\link[=ggplot]{ggplot}})
#' @return Returns a list of strings describing quantiles

legend.quantile <- function ( quantile, shift=1 ) {
  if ( max( quantile ) < 1 )  {
    q <- quantile * 10
  } else {
    q <- quantile
  }
  q <- c( rep( 0, shift ), q )
  sapply( 2:length( q ), function( i ) { 
    paste( q[i-1], "to", q[i], "quantiles" ) } )
}

## ---- title.plot.elem  ----
#' Plot title font
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @return Returns \code{element_text( size=12, colour = "black", face="bold", 
#'   vjust=0.12 )}

title.plot.elem <- function () {
  return( element_text( size=12, colour = "black", face="bold", vjust=0.12 ) )
}

## ---- template.plot.hourly  ----
#' Temporal plot template
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param x   data frame to plot
#' @param breaks   tick mark positions
#' @param xTick   x-axis labels
#' @param legPos   legend position (defaults to 'bottom') 
#' @param size   grid line size (defaults to 1)
#' @param colour   grid line color (defaults to black)
#' @param linetype  grid line type (defaults to "dotted")
#' @param xAngle  angle of rotation for x-axis labels (defaults to 90, 
#'   counterclockwise)
#' @return Returns a ggplot object with the specified parameters

template.plot.hourly <- function ( x, breaks, xTick, legPos="bottom", 
                                   size=1, colour="black", linetype="dotted",
                                   xAngle=90 ) {
  ggplot( x ) +
    scale_x_continuous( breaks = breaks, labels=xTick ) +
    theme( axis.text = element_text( size=11, colour="black", face="bold" ),
           axis.text.x = element_text( angle = xAngle ),
           title = title.plot.elem(),
           panel.grid.major=element_line( colour=colour, linetype=linetype, 
                                          size=size ),
           panel.background=element_blank(),
           legend.position=legPos )
}

## ---- plots.order  ----
#' Order a list of plots
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param x   (named) list of plots 
#' @param order   sort order
#' @return Returns the original list of plots in the specified order

plots.order <- function( x, order ) {
  po <- lapply( order, function(c) x[[c]] )
  names( po ) <- order
  return( po )
}
  
## ---- theme.ribbon  ----
#' Create a \code{\link[=ggplot]{ggplot}} theme for a ribbon plot
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param legPos   legend position (deafults to 'bottom')
#' @return Returns a theme for a ribbon plot

theme.ribbon <- function( legPos="bottom" ) {
  return( 
    theme( axis.text = element_text( size=11, colour="black", face="bold" ),
           title = element_text( size=12, colour = "black", face="bold",
                                 vjust=0.12 ),
           panel.grid.major=element_line( colour="black", linetype="dotted" ),
           panel.background=element_blank( ), legend.position=legPos )
  )
}

## ---- x.tick.hourly  ----
#' Tick marks for a weekly hour-by-hour plot
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param xStep   tick interval (deafults to 4)
#' @return Returns a vector of tick marks in the form of 
#'   "<one-letter day of the week>.<hour of the day out of 24>"

x.tick.hourly <- function( xStep = 4 ) {
  xm <- hours24()
  xInd <- xm[xm %% xStep == 0]
  xTickSeq <- Reduce( c, lapply( weekdays(), 
                                 function( h ) paste( h, xInd, sep="." ) ) )
  return( xTickSeq )
}

## ---- x.mark.hourly  ----
#' X-axis tick placement for a weekly hour-by-hour plot
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param mark   original x-axis coordinates from \code{x}
#' @param xStep   tick interval (deafults to 4)
#' @return Returns a vector of tick mark coordinates as an equidistant sequence 

x.mark.hourly <- function( mark, xStep=4 ) {
  return( unique( mark[mark %% xStep == 0] ) )
}

## ---- lm.eqn  ----
#' Construct a linear regression equation string from \code{x} and \code{y} 
#'   using \code{lm}
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param x   x-values
#' @param y   y-values
#' @return Returns a string containing the regression equation obtained using
#'   \code{lm( y ~ x )} 

lm.eqn = function( x, y ){
  m = lm( y ~ x );
  eq <- substitute( italic( y ) == a + b %.% italic( x ) * 
                      ","~~"adj."~ italic( r )^2~"="~r2, 
                    list( a = format( coef( m )[1], digits = 2 ), 
                          b = format( coef( m )[2], digits = 2 ), 
                          r2 = format( summary( m )$r.squared, digits = 3 ) ) )
  as.character( as.expression( eq ) );
}


