## ---- NS.CA.round ----
#' Mathematically correct rounding
#' @description Rounds numbers down when the lat digit is less than 5, up 
#'   otherwise
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param  x   real number
#' @return   Returns (integer) ceiling(x) if x ends in 0.5 or greater;
#' floor(x) otherwise


NS.CA.round <- function( x ) {
  return( ifelse( x-floor( x ) < 0.5, floor( x ), ceiling( x ) ) )
}

## ---- min.max.step ----
#' Min to max sequence from a vector
#' @description From a numeric vector generates a sequence from \code{min} to 
#'   \code{max} with a given step
## Arguments
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @param x   vector of numbers
#' @param step  step of the sequence (defaults to 1)
#' @return   returns a sequence of numbers from min(x) to max(x) spaced at 
#'   \code{step}

minmax.step <- function( x, step=1 ) {
  s <- unique( x )
  return( seq( min( s ), max( s ), by=step ) )
}
