#' NS.CA.mathUtils.
#'
#' Auxiliary and mathematical functions redefined from base (e.g.,
#' NS.CA.mathUtils:round provides standard mathematical, not IEEE, rounding)
#'
#' @note This code is intended for education and information sharing purposes  
#'   only. NorthShore University HealthSystem is not responsible for any  
#'   unintended consequences resulting from the implementation thereof.   
#'   Please use at your own risk.
#' @name NS.CA.mathUtils
#' @docType package
NULL
