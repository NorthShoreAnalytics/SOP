#' NS.CA.mathUtils.
#'
#' Auxiliary and mathematical functions redefined from base (e.g.,
#' NS.CA.mathUtils:round provides standard mathematical, not IEEE, rounding)
#'
#' @name NS.CA.mathUtils
#' @docType package
NULL
